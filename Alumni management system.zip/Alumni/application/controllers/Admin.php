<?php

class Admin extends MY_Controller
{
    public $course ='';
    public function __construct()
    {
        parent::__construct();
        //Loading the Models
        $this->load->model('Academics');
        $this->load->model('Business');
        $this->load->model('General_Info');
        $this->load->model('Jobs');
        $this->load->library('ion_auth');

        if (!$this->ion_auth->logged_in() && !$this->ion_auth->is_admin())
        {


            redirect(base_url() . 'index.php/User');
        }
        $this->course = $this->ion_auth->user()->row()->department;
    }

    public function index(){

     //DASHBOARD
        if($this->ion_auth->is_admin()){
            $data['quick_search'] =$this->General_Info->get();
        }else{
            $data['quick_search'] =$this->General_Info->get_by(array('course'=>$this->course),FALSE);
        }

        /*$data['industries'] = $this->Jobs->get_industries();*/
        /*$data['courses'] = $this->General_Info->get_courses();*/
        $data['total_members'] = $this->General_Info->total_members();
        //Generating the Views
        $this->load->view('admin/header');
        $this->load->view('admin/dashboard', $data);
        $this->load->view('admin/footer');
    }

    public function database(){
        $title['dashboard'] = 'MeraCodePadega?';
        $data['information'] = $this->get_database();
        //Generating the Views
        $this->load->view('admin/header');
        $this->load->view('admin/database', $data);
        $this->load->view('admin/footer');
    }

    public function general_info(){
        $title['general_info'] = 'YO';
        //echo $this->course;
        $data['information'] = $this->General_Info->get_basic();
        //Generating the Views
        $this->load->view('admin/header',$title);
        $this->load->view('admin/basic', $data);
        $this->load->view('admin/footer');
    }

    public function jobs(){
        $title['jobs'] = 'YO';
        $data['information'] = $this->Jobs->get_jobs();
        //Generating the Views
        $this->load->view('admin/header',$title);
        $this->load->view('admin/jobs', $data);
        $this->load->view('admin/footer');
    }

    public function academics(){
        $title['academics'] = 'YO';
        $data['information'] = $this->Academics->get_studies();
        //Generating the Views
        $this->load->view('admin/header',$title);
        $this->load->view('admin/academics', $data);
        $this->load->view('admin/footer');
    }

    public function business(){
        $title['business'] = 'YO';
        $data['information'] = $this->Business->get_business();
        //Generating the Views
        $this->load->view('admin/header',$title);
        $this->load->view('admin/business', $data);
        $this->load->view('admin/footer');
    }

    public function request(){
        $this->load->model("Requests");
        $data['requests'] = $this->Requests->view($this->id);
        $r['request'] = '';
        $this->load->view("Admin/header",$r);
        $this->load->view("Admin/request_dashboard",$data);
        $this->load->view("Admin/footer");
    }

    public function event(){
        $r['event'] = '';
        $this->load->model("Events");
        $data['events'] = $this->Events->view($this->id);
        $this->load->view('admin/header',$r);
        $this->load->view('admin/events_dashboard',$data);
        $this->load->view('admin/footer');
    }

    public function event_response($id){
        $r['event'] = '';
        $this->load->model("Events");
        $data['event'] = $this->Events->get_by(array('e_id'=>$id), TRUE);

        $this->db->select("*");
        $this->db->from("events_data");
        $this->db->join("events","ed_id=e_id");
        $this->db->join("users","user=id");
        $this->db->where("e_id = $id");
        $data['details'] = $this->db->get()->result_object();

        foreach($data['details'] as $d){
            if($d->status == 0){
                $d->stat = "Not Attending";
            }elseif($d->status == 1){
                $d->stat = "Maybe";
            }else{
                $d->stat = "Attending";
            }
        }
        $this->load->view('admin/header', $r);
        $this->load->view('admin/event_response', $data);
        $this->load->view('admin/footer');
    }

    public function response($request){
        $this->load->model("Responses");
        $this->load->model("Requests");
       $data['responses'] = $this->Responses->view($request);
       $data['request'] = $this->Requests->get_by(array("r_id"=>$request),TRUE);
        $this->load->view("Admin/header");
        $this->load->view("Admin/response", $data);
        $this->load->view("Admin/footer");
    }

    public function logout(){

        redirect(base_url() . 'index.php/User');
    }

    private function get_database(){
        $query = $this->db->query("SELECT first_name, last_name, phone_no, email, passed_year, jobs.company_name,business.company_name as business_name, jobs.industry, business.industry as business_industry, academics.college_name, academics.field_of_study FROM general_info LEFT JOIN jobs on general_info.id = jobs.s_id LEFT JOIN business on general_info.id = business.s_id LEFT JOIN academics on general_info.id = academics.s_id ");
        return $query->result();
    }



}
