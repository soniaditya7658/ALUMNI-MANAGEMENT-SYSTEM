<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Alumni extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        //Loading the Models
        $this->load->model('Academics');
        $this->load->model('Business');
        $this->load->model('General_Info');
        $this->load->model('Jobs');
        $this->load->Library('email');
    }

    public function index()
    {
        $this->load->library('ion_auth');
        $this->ion_auth->logout();
        //$this->load->view('welcome_message');
        $this->load->view('login');

    }

    public function login(){
        $this->load->library('ion_auth');
        $email = $this->input->post('email');
        $password = $this->input->post('password');

        if($this->ion_auth->login($email, $password) && $this->ion_auth->in_group('3')){
            echo 'Welcome!';
        }else{
            redirect(base_url() .'index.php/Alumni/index?error=TRUE');
        }
    }
    public function signup(){
        $email = $this->input->post('email');
        $password = $this->input->post('password');
        $c_password = $this->input->post('c_password');

        if($password !== $c_password){
            redirect(base_url() . 'index.php/Alumni?error=TRUE');
        }else{
            $this->load->library('ion_auth');
            $addional_data = [];
            $group = array('3'); // sets to student
            $this->ion_auth->register('',$email,$password,$addional_data, $group);

        }
    }
    public function Forgot_password(){
		$this->load->model('General_Info');
        $email = $this->input->post('email');
		$query=$this->db->query("select * from general_info where email='".$email."'");
		$query->result_array();
        if($query->num_rows()>0){
			$config = Array(
				'protocol' => 'smtp',
				'smtp_host' => 'ssl://tcsc.ac.in',
				'smtp_port' => 465,
				'smtp_user' => 'admin@tcsc.ac.in',
				'smtp_pass' => '$aditya@1997',
				'mailtype'  => 'html',
				'charset'   => 'iso-8859-1',
				'wordwrap'  => TRUE
			);
			$this->load->Library('email',$config);
			$subject = "Reset password link";
		    $htmlContent = '<a href= "tcsc.ac.in/Alumni/index.php/reset_password">';
			$this->email->set_newline("\r\n");
			$this->load->Library('email');
			$this->email->to($email);
			$this->email->from('admin@tcsc.ac.in', 'TCSC Alumni Portal');
			$this->email->subject($subject);
			$this->email->message($htmlContent);
			if ($this->email->send()) {
				echo "Email sent successfully";
			} else {
				show_error($this->email->print_debugger());
			}
		}
		else{
			echo "email not found";
		}
        $this->load->view('Forgot_password');
	}
    public function register(){


        $first_name = $this->input->post('first_name');
        $middle_name = $this->input->post('middle_name');
        $last_name = $this->input->post('last_name');
        $gender = $this->input->post('gender');
        $mothers_name = $this->input->post('mothers_name');
        $fathers_name = $this->input->post('fathers_name');
        $dob = $this->input->post('dob');
        $address = $this->input->post('address');
        $phone = $this->input->post('phone');
        $email = $this->input->post('email');
        $current = $this->input->post('current');
        $uid = $this->input->post('uid');
        $course = $this->input->post('course');
        $passed_year = $this->input->post('passed_year');
        $avg_percent = $this->input->post('avg_percent');

        //JOB
        $jcompany = $this->input->post('jcompany');
        $jposition = $this->input->post('jposition');
        $jctc = $this->input->post('jctc');
        $jplacement_type = $this->input->post('jplacement_type');
        $jindustry = $this->input->post('jindustry');
        $jstart_date = $this->input->post('jstart_date');
        //$jend_date = $this->input->post('jend_date');

        //Studies
        $fcollege = $this->input->post('fcollege');
        $fdegree = $this->input->post('fdegree');
        $ffield_of_study = $this->input->post('ffield_of_study');
        $fstart_year = $this->input->post('fstart_year');
        $fend_year = $this->input->post('fend_year');

        //Business
        $bcompany = $this->input->post('bcompany');
        $baddress = $this->input->post('baddress');
        $bindustry = $this->input->post('bindustry');
        $bdescription = $this->input->post('bdescription');
        $bturnover = $this->input->post('bturnover');

        $reid = $this->General_Info->save(array(
            'first_name' => $first_name,
            'middle_name' => $middle_name,
            'last_name' => $last_name,
            'gender' => $gender,
            'mothers_name' => $mothers_name,
            'fathers_name' => $fathers_name,
            'date_of_birth' => $dob,
            'address' => $address,
            'phone_no' => $phone,
            'email' => $email,
            'uid' => $uid,
            'course' => $course,
            'passed_year' => $passed_year,
            'average_percentage' => $avg_percent
        ));

        $query = $this->db->query("SELECT id from general_info where uid = '$uid'");

        $s_id = $query->result();
        $s_id = $s_id[0]->id;
        if($current == 'job'){
            $s_id =   $this->Jobs->save(array(
                's_id' => $s_id,
                'company_name' => $jcompany,
                'position' => $jposition,
                'ctc'=> $jctc,
                'placement_type' => $jplacement_type,
                'start_date' => $jstart_date,
                'industry' => $jindustry
            ));
        }elseif ($current == 'studies'){
            $s_id =   $this->Academics->save(array(
                's_id' => $s_id,
                'college_name' => $fcollege,
                'field_of_study' => $ffield_of_study,
                'start_year'=> $fstart_year,
                'end_year' => $fend_year,
                'degree' => $fdegree
            ));
        }else{
           $s_id = $this->Business->save(array(
                's_id' => $s_id,
                'company_name' => $bcompany,
                'office_address' => $baddress,
                'industry'=> $bindustry,
                'description' => $bdescription,
                'turnover' => $bturnover
            ));
        }

        if($reid != NULL and $s_id != NULL){
            redirect(base_url() . 'index.php/Alumni?success=true');
        }

    }
}
