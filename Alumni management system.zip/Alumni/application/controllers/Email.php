<?php
ini_set('max_execution_time', 0);
ini_set('memory_limit','2048M');
class Email extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();

    }

    public function index(){

        $this->load->view('Admin/header');
        $this->load->view('Admin/email');
        $this->load->view('Admin/footer');
		$this->load->library('email');
		$this->load->helper('url');
		$this->load->model('Users');
    }

    public function send(){


        $config = Array(
            'protocol' => 'smtp',
            'smtp_host' => 'Your host name',
            'smtp_port' => 465,
            'smtp_user' => 'Your user email',
            'smtp_pass' => 'Your password',
            'mailtype'  => 'html',
            'charset'   => 'iso-8859-1',
			'wordwrap'  => TRUE
        );
        $this->load->library('email', $config);
        $this->email->set_newline("\r\n");

        $subject = $this->input->get('subject');
        $body = $this->input->get('body');

        $this->db->select("email");
        $emails = $this->db->get("users");
        $test_email = ['sudanprabjyot@gmail.com','prabjyotsudan@gmail.com','adityasoniharshad@gmail.com','meetsoni58@gmail.com'];

        //Load email library
        $this->load->library('email');
        foreach($emails->result() as $row) {
			$this->email->from('admin@tcsc.ac.in', 'TCSC Alumni Portal');
        	$this->email->to($row->email);
			$this->email->subject($subject);
			$this->email->message($body);
		}
		//Send mail
		if ($this->email->send()) {
			echo "Email sent successfully";
		} else {
			show_error($this->email->print_debugger());
		}

    }
}
