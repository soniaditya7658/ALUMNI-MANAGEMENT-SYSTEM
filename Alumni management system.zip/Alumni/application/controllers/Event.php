<?php
class Event extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->library('ion_auth');
        $this->load->model("Events");

        /*if (!$this->ion_auth->logged_in())
        {
            redirect(base_url() . 'index.php/User');
        }*/

    }

    public function add()
    {
        //TItle, by, description

        $title = $this->input->post('title');
        $description = $this->input->post('description');
        $by = $this->ion_auth->user()->row()->id;
        $data = $this->image_upload();

        //var_dump($data);
        $data1 = $this->do_upload();
//var_dump($data1);
        if(isset($data['upload_data']['file_name']) && isset($data['upload_data']['file_name'])) {
            $file = $data['upload_data']['file_name'];
            $image = $data1['upload_data']['file_name'];
            $this->Events->add($title, $by, $description, $file,$image);

            redirect(base_url() . 'index.php/Admin/event');
        }
    }

    public function delete($id)
    {
        $this->Events->delete($id);
        redirect(base_url() . 'index.php/Admin/event');
    }

    public function status(){
        //Check if the status already exist?
        $id = $this->id;
        $status = $this->input->post('status');
        $event_id = $this->input->post('id');

        $this->load->model('Events_data');
        $events = $this->Events_data->get_by(array('user'=>$id,'event'=>$event_id), TRUE);

        if(count($events) == 0){
            $r_id = $this->Events_data->save(array(
                'event' => $event_id,
                'user' => $id,
                'status' => $status
            ));
            if($r_id != ''){
                echo "attending";
            }
        }else{

            $data = array(
                'user' => $id,
                'status' => $status
            );

            $this->db->where('event', $event_id);
            $this->db->update('events_data', $data);

        }

    }

    public function do_upload() {
        $config['upload_path']   = './uploads/';
        $config['allowed_types'] = 'pdf|docx|png|jpg|jpeg';
        $config['max_size']      = 100000;
        $config['max_width']     = 3000;
        $config['max_height']    = 3000;
        $this->load->library('upload', $config);

        if ( ! $this->upload->do_upload('userfile')) {
            $error = array('error' => $this->upload->display_errors());
            return $error;
        }

        else {
            $data = array('upload_data' => $this->upload->data());
            return $data;
        }
    }

    public function image_upload() {
        $config['upload_path']   = './uploads/';
        $config['allowed_types'] = 'pdf|docx|png|jpg|jpeg';
        $config['max_size']      = 100000;
        $config['max_width']     = 3000;
        $config['max_height']    = 3000;
        $this->load->library('upload', $config);

        if ( ! $this->upload->do_upload('imagefile')) {
            $error = array('error' => $this->upload->display_errors());
            return $error;
        }

        else {
            $data = array('upload_data' => $this->upload->data());
            return $data;
        }
		
		
    }
}