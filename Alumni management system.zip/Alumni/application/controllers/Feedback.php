<?php
class Feedback extends MY_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Feedbacks');
    }
    public function dashboard(){

        $this->load->view('Admin/header');
        $this->load->view('Admin/feedback');
    }
    public function check(){
        if($this->Feedbacks->check($this->id, 5)){
            return true;
        }else{
            return false;
        }
    }

    public function add(){
        $answer1 = $this->input->post('question1');
        $answer2 = $this->input->post('question2');
        $answer3 = $this->input->post('question3');
        $answer4 = $this->input->post('question4');
        $answer5 = $this->input->post('question5');
        $answers = [$answer1,$answer2,$answer3,$answer4,$answer5];
        var_dump($answers);
        $this->Feedbacks->add($this->id,$answers);

        redirect(base_url() . 'index.php/Student');

    }
}