<?php
class Hod extends MY_Controller
{
	public $course ='';
	public function __construct()
	{
		parent::__construct();
		//Loading the Models
		$this->load->model('Academics');
		$this->load->model('Business');
		$this->load->model('General_Info');
		$this->load->model('Jobs');
		$this->load->library('ion_auth');
		if (!$this->ion_auth->logged_in() && !$this->ion_auth->in_group(2))
		{
			redirect(base_url() . 'index.php/User/hod_login');
		}
		$course = $this->ion_auth->user()->row()->department;
	}
	
	
	public function index(){

		//DASHBOARD
		if($this->ion_auth->logged_in() && $this->ion_auth->in_group(2)){
			$data['quick_search'] =$this->General_Info->get();
		}else{
			$data['quick_search'] =$this->General_Info->get_by(array('course'=>$this->course),FALSE);
		}

		/*$data['industries'] = $this->Jobs->get_industries();*/
		/*$data['courses'] = $this->General_Info->get_courses();*/
		$data['total_members'] = $this->General_Info->total_members_hod();
		//Generating the Views
		$this->load->view('hod/header');
		$this->load->view('hod/dashboard', $data);
		$this->load->view('hod/footer');
	}

	public function database(){
		$title['dashboard'] = 'MeraCodePadega?';
		$data['information'] = $this->get_database();
		//Generating the Views
		$this->load->view('hod/header');
		$this->load->view('hod/database', $data);
		$this->load->view('hod/footer');
	}

	public function general_info(){
		$title['general_info'] = 'YO';
		//echo $this->course;
		$data['information'] = $this->General_Info->get_basic_hod();
		//Generating the Views
		$this->load->view('hod/header',$title);
		$this->load->view('hod/basic', $data);
		$this->load->view('hod/footer');
	}

	public function jobs(){
		$title['jobs'] = 'YO';
		$data['information'] = $this->Jobs->get_jobs_hod();
		//Generating the Views
		$this->load->view('hod/header',$title);
		$this->load->view('hod/jobs', $data);
		$this->load->view('hod/footer');
	}

	public function academics(){
		$title['academics'] = 'YO';
		$data['information'] = $this->Academics->get_studies_hod();
		//Generating the Views
		$this->load->view('hod/header',$title);
		$this->load->view('hod/academics', $data);
		$this->load->view('hod/footer');
	}

	public function business(){
		$title['business'] = 'YO';
		$data['information'] = $this->Business->get_business_hod();
		//Generating the Views
		$this->load->view('hod/header',$title);
		$this->load->view('hod/business', $data);
		$this->load->view('hod/footer');
	}

	public function logout(){

		redirect(base_url() . 'index.php/User/hod_login');
	}

	private function get_database(){
		$query = $this->db->query("SELECT first_name, last_name, phone_no, email, passed_year, jobs.company_name,business.company_name as business_name, jobs.industry, business.industry as business_industry, academics.college_name, academics.field_of_study FROM general_info LEFT JOIN jobs on general_info.id = jobs.s_id LEFT JOIN business on general_info.id = business.s_id LEFT JOIN academics on general_info.id = academics.s_id ");
		return $query->result();
	}



}

