<?php
class Request extends MY_Controller
{
    public $course ='';
    public function __construct()
    {
        parent::__construct();

        $this->load->library('ion_auth');
        $this->load->model("Requests");

        /*if (!$this->ion_auth->logged_in())
        {
            redirect(base_url() . 'index.php/User');
        }*/
           // $this->course = $this->ion_auth->user()->row()->department;
    }

    public function add()
    {
        //echo base_url() . 'public_html/uploads';
        //TItle, by, description
        $title = $this->input->post('title');
        $description = $this->input->post('description');
        $by = $this->ion_auth->user()->row()->id;
        $data = $this->do_upload();
        if(isset($data['upload_data']['file_name'])){
            $file = $data['upload_data']['file_name'];
            $this->Requests->add($title, $by, $description, $file);

            redirect(base_url() . 'index.php/Admin/request');
        }

    }

    public function delete($id)
    {
        $this->Requests->delete($id);
        redirect(base_url() . 'index.php/Admin/request');
    }

    public function reply(){
        $id = 1;
        $response = $this->input->post('text');
        $req_id = $this->input->post('id');

        $this->load->model('Reply');
        $rid = $this->Reply->save(array(
            'req_id'=>$req_id,
            'text'=>$response,
            'user_id'=>$id
        ));

        if($rid != ''){
            echo 'Thank you for your Response!';
        }
    }

    public function do_upload() {
        $config['upload_path']   = './uploads/';
        $config['allowed_types'] = 'pdf|docx|png|jpg|jpeg';
        $config['max_size']      = 1000;
        $config['max_width']     = 1024;
        $config['max_height']    = 768;
        $this->load->library('upload', $config);

        if ( ! $this->upload->do_upload('userfile')) {
            $error = array('error' => $this->upload->display_errors());
            return $error;
        }

        else {
            $data = array('upload_data' => $this->upload->data());
            return $data;
        }
    }

}