<?php
class Student extends User_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model("requests");
        $this->load->model("events");
    }

    public function index(){
		if ($this->ion_auth->in_group(3)){
			$data['events'] = $this->events->view();
			$data['requests'] = $this->requests->view();

			$this->load->model('Feedbacks');
			if($this->Feedbacks->check($this->id,5)){
				//echo 'yes';
				$data['display'] = 1;
			}else{
				$data['display'] = 0;
			}
			$this->load->view('header');
			$this->load->view('dashboard', $data);
			$this->load->view('footer');
		}else{
			redirect(base_url());
		}
    }

    public function profile(){
		if ($this->ion_auth->in_group(3)){
        $this->load->model('General_info');
        $this->load->model('Jobs');
        $this->load->model('Business');
        $this->load->model('Academics');
        //var_dump($this->General_info->get_student_info(9));
       $data['basic_info'] = $this->General_info->get_student_info($this->id);

       $data['jobs'] = $this->Jobs->get_student_jobs($this->id);

        $data['academics'] = $this->Academics->get_student_studies($this->id);

        $data['business'] = $this->Business->get_student_business($this->id);

        $this->load->view('header');
        $this->load->view('profile',$data);
        $this->load->view('footer');
		}else{
			redirect(base_url());
		}
		
    }
    public function upload_pic(){
        //upload file
        $config['upload_path'] = './uploads/';
        $config['allowed_types'] = '*';
        $config['max_filename'] = '255';
        $config['encrypt_name'] = TRUE;
        $config['max_size'] = '10000'; //1 MB
        $this->load->model('General_info');

        if (isset($_FILES['file']['name'])) {
            if (0 < $_FILES['file']['error']) {
                echo 'Error during file upload' . $_FILES['file']['error'];
            } else {

                    $this->load->library('upload', $config);
                    if (!$this->upload->do_upload('file')) {
                        echo $this->upload->display_errors();
                    } else {

                        $data = array(
                            'image'=>$_FILES['file']['name']
                        );
                        $this->db->where('user_id',$this->id);
                        $this->db->update('general_info', $data);
                        echo $_FILES['file']['name'];
                    }

            }
        } else {
            echo 'Please choose a file';
        }
    }


    public function update_basic(){
		if ($this->ion_auth->in_group(3)){
        $this->load->model('General_info');

        $first_name = $this->input->post('first_name');
        $middle_name = $this->input->post('middle_name');
        $last_name = $this->input->post('last_name');
        $gender = $this->input->post('gender');
        $mothers_name = $this->input->post('mothers_name');
        $fathers_name = $this->input->post('fathers_name');
        $dob = $this->input->post('dob');
        $address = $this->input->post('address');
        $phone = $this->input->post('phone');
        $uid = $this->input->post('uid');
        $course = $this->input->post('course');
        $passed_year = $this->input->post('passed_year');
        $avg = $this->input->post('average_grade');
		$email = $this->input->post('email');
      
                $data = array(
                    'first_name' => $first_name,
                    'middle_name' => $middle_name,
                    'last_name' => $last_name,
                    'gender'=>$gender,
					'email' => $email,
                    'mothers_name' => $mothers_name,
                    'fathers_name' => $fathers_name,
                    'date_of_birth' => $dob,
                    'address' => $address,
                    'phone_no' => $phone,
                    'uid' => $uid,
                    'course' => $course,
                    'passed_year' => $passed_year,
                    'average_percentage' => $avg
                );
            
        if(count($this->General_info->get_by(array('user_id'=>$this->id), FALSE)) > 0){

			$this->db->where('user_id', $this->id);
            if($this->db->update('general_info', $data)){
               redirect(base_url() . 'index.php/Student/profile?status=1');
            }else{
                echo 'Problem Updating your details';
            }
			
		}else{
			$data['user_id'] = $this->id;
			$this->General_info->save($data);
			redirect(base_url() . 'index.php/Student/profile?status=1');
		}
        
		}else{
			redirect(base_url());
		}

    }

    public function connect(){
		if (!$this->ion_auth->in_group(3)){
			redirect(base_url());
		}
        $this->load->model("General_info");
		$this->load->model("Users");

        if(!isset($_GET['srch-term'])){
            $data['users'] = $this->General_info->get_by(array("user_id !="=> $this->id),FALSE);

        }else{
            $search = $_GET['srch-term'];
            $this->db->select("general_info.user_id,users.username, general_info.first_name, general_info.last_name, users.email,general_info.image as image");
            $this->db->distinct("users.id");
            $this->db->from("users");
            $this->db->join("general_info","users.id = user_id");
            $this->db->join("jobs","users.id = user_id");
            $this->db->join("academics","users.id = academics.s_id");

            $this->db->like("general_info.first_name",$search,'left');
            $this->db->or_like("general_info.last_name", $search,'left');
            $this->db->or_like("college_name",$search,'left');
            $this->db->or_like("field_of_study",$search,'left');
            $this->db->or_like("company_name", $search,'left');
            $this->db->or_like("industry",$search,'left');

            $data['users'] = $this->db->get()->result_object();
        }


        $this->load->view("header");
        $this->load->view("search",$data);

    }

    public function add_exp(){
        $company_name = $this->input->post('company');
        $position = $this->input->post('position');
        $start_date = $this->input->post('start_year');
        $industry = $this->input->post('industry');
		$data = array(
		'company_name' => $company_name,
		'position' => $position,
		'start_year' => $start_date,
		'industry' => $industry,
		's_id'=>$this->id
		);

        $this->load->model('Jobs');
		if(count($this->Jobs->get_by(array('s_id'=> $this->id), FALSE)) > 0){
		
       $re_id = $this->db->query("UPDATE jobs set company_name = '$company_name', position='$position', start_year = '$start_date', industry = '$industry' where s_id = $this->id");
        if($re_id != null){
            redirect(base_url() . 'index.php/Student/profile?status=1');
        }else{
            redirect(base_url() . 'index.php/Student/profile');
        }
		}else{
			$this->Jobs->save($data);
			redirect(base_url() . 'index.php/Student/profile?status=1');
		}

    }

    public function edit_exp($id){
        $company_name = $this->input->post('company');
        $position = $this->input->post('position');
        $start_date = $this->input->post('start_year');
        $end_date = $this->input->post('end_year');
        $industry = $this->input->post('industry');

        $this->load->model('Jobs');
        $this->Jobs->save(array(
            'company_name'=> $company_name,
            'position'=>$position,
            'start_year' => $start_date,
            'end_year' => $end_date,
            'industry' => $industry,
            's_id'=>$this->id
        ),$id);

        redirect(base_url() . 'index.php/Student/profile');
    }

    public function del_exp($id){
        $this->load->model("Jobs");
        $this->Jobs->delete($id);

        redirect(base_url() . 'index.php/Student/profile');
    }
    public function add_edu(){
        $institute = $this->input->post('institute');
        $fos = $this->input->post('fos');
        $start_date = $this->input->post('start_year');

        $degree = $this->input->post('degree');
		
		$data = array(
			'college_name' => $institute,
			'field_of_study' => $fos,
			'start_year' => $start_date,
			'degree' => $degree,
			's_id'=>$this->id
		);

        $this->load->model('Academics');
		if(count($this->Academics->get_by(array('s_id'=>$this->id)), FALSE) > 0){
        $re_id = $this->db->query("UPDATE academics set college_name = '$institute', field_of_study = '$fos', start_year = '$start_year', degree = '$degree' where s_id = $this->id");

        redirect(base_url() . 'index.php/Student/profile?status=1');
		}else{
			$this->Academics->save($data);
			redirect(base_url() . 'index.php/Student/profile?status=1');
		}
    }
    public function add_bus(){
        $c_name = $this->input->post('c_name');
        $industry = $this->input->post('industry');
        $start_year = $this->input->post('start_year');
        //$end_year = $this->input->post('end_year');
        $description = $this->input->post('description');

        $this->load->model('Business');
        $this->Business->save(array(
            'company_name'=> $c_name,
            'industry'=>$industry,
            'start_year' => $start_year,
            'end_year' => $end_year,
            'description' => $description,
            's_id'=>$this->id
        ));
		
		if(count($this->Business->get_by(array('s_id'=>$this->id), FALSE)) > 0){
			$re_id = $this->db->query("UPDATE business set company_name = '$c_name', industry = '$industry', start_year = '$start_year', description = '$description' where sid = $this->id");
			redirect(base_url() . 'index.php/Student/profile?status=1');
		}
		else{
			$this->Business->save($data);
			redirect(base_url() . 'index.php/Student/profile?status=1');
		}
    }
    public function edit_edu(){
        $institute = $this->input->post('institute');
        $fos = $this->input->post('fos');
        $start_date = $this->input->post('start_year');
        $end_date = $this->input->post('end_year');
        $degree = $this->input->post('degree');

        $this->load->model('Academics');
        $a = $this->Academics->get_by(array('s_id'=>$this->id), false);
        if(count($a) >= 1 ){
            $id = $a[0]->a_id;
            $this->Academics->save(array(
                'college_name'=> $institute,
                'field_of_study'=>$fos,
                'start_year' => $start_date,
                'degree' => $degree,
                's_id'=>$this->id
            ),$id);
        }else{
            $this->Academics->save(array(
                'college_name'=> $institute,
                'field_of_study'=>$fos,
                'start_year' => $start_date,

                'degree' => $degree,
                's_id'=>$this->id
            ));
        }


        redirect(base_url() . 'index.php/Student/profile');
    }
    public function edit_bus(){
    $c_name = $this->input->post('c_name');
    $industry = $this->input->post('industry');
    $start_year = $this->input->post('start_year');

    $description = $this->input->post('description');

    $this->load->model('Business');
        $b = $this->Business->get_by(array('s_id'=>$this->id), false);
        if(count($b) >= 1 ) {
            $id = $b[0]->b_id;
            $this->Business->save(array(
                'company_name' => $c_name,
                'industry' => $industry,
                'start_year' => $start_year,
                'description' => $description,
                's_id' => $this->id
            ), $id);
        }else{
            $this->Business->save(array(
                'company_name' => $c_name,
                'industry' => $industry,
                'start_year' => $start_year,
                'description' => $description,
                's_id' => $this->id
            ));
        }
        redirect(base_url() . 'index.php/Student/profile');
}
    public function del_edu($id){
        $this->load->model("Academics");
        $this->Academics->delete($id);
        redirect(base_url() . 'index.php/Student/profile');
    }
    public function del_bus($id){
        $this->load->model('Business');
        $this->Business->delete($id);
        redirect(base_url() . 'index.php/Student/profile');
    }

    public function view($id){
		if (!$this->ion_auth->in_group(3)){
			redirect(base_url());
		}
        $this->load->model('General_info');
        $this->load->model('Jobs');
        $this->load->model('Business');
        $this->load->model('Academics');
        //var_dump($this->General_info->get_student_info(9));
        $data['basic_info'] = $this->General_info->get_student_info($id);

        $data['jobs'] = $this->Jobs->get_student_jobs($id);

        $data['academics'] = $this->Academics->get_student_studies($id);
		
		$data['business'] = $this->Business->get_student_business($id);

        $this->load->view('header');


      $this->load->view('view_profile',$data);
    }

    public function logout(){
        $this->load->library('ion_auth');
        $this->ion_auth->logout();
        redirect(base_url() . 'index.php/Alumni');
    }

    public function image_upload() {
        $config['upload_path']   = 'uploads/';
        $config['allowed_types'] = 'png|jpg|jpeg';
        $config['max_size']      = 10000;
        $config['max_width']     = 3000;
        $config['max_height']    = 3000;
        $this->load->library('upload', $config);

        if ( ! $this->upload->do_upload('file')) {
            $error = array('error' => $this->upload->display_errors());
            echo $error[0];
        }

        else {
            $data = array('upload_data' => $this->upload->data());
            $name = $data['upload_data']['file_name'];
			$this->load->model('General_info');
			if(count($this->General_info->get_by(array('user_id'=>$this->id), FALSE)) > 0){
			$this->db->query("UPDATE general_info set image = '$name' where user_id = $this->id");
				
			}else{
				$this->General_info->save(array('image'=>$name, 'user_id'=> $this->id));
			}
			echo $name;
        }
    }
}
