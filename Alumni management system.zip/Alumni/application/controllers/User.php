<?php
class User extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('ion_auth');

    }
//localhot/User/indrex
    public function index(){
        $this->ion_auth->logout();
        $this->load->view('admin/login');
		$this->load->view('hod/login');

    }

    public function student_login(){
        $this->load->library('ion_auth');
        $email = $this->input->post("email");
        $password = $this->input->post("password");

        if($this->ion_auth->login($email, $password)){
            redirect(base_url() .'index.php/Student');
        }else{
            redirect(base_url() .'index.php/Alumni?status=wrong');
        }
    }

    public function student_register(){
        $email = $this->input->post('email');
        $password = $this->input->post('password');
        $f_name = $this->input->post('first_name');
        $l_name = $this->input->post('last_name');
        $additional_data = array(
            'first_name' => $f_name,
            'last_name' => $l_name
        );
        $group = array('3');
        $x = $this->ion_auth->register('', $password, $email, $additional_data, $group);
        if(isset($x)){
            $this->load->model('General_info');
            $this->General_info->save(array(
                'first_name'=>$f_name,
                'last_name'=>$l_name,
                'email'=>$email,
                'user_id'=> $x
            ));

            redirect(base_url() .'index.php/Alumni?success=true');
        }else{
            redirect(base_url() .'index.php/Alumni?success=false');
        }
    }
    public function login(){
        $email = $this->input->post('email');
        $password = $this->input->post('password');

        if($this->ion_auth->login($email, $password)){
            redirect(base_url() .'index.php/Admin');
        }else {
			redirect(base_url() . 'index.php/User');
		}
    }
	
	public function hod_login()
	{

			$email = $this->input->post('email');
			$password = $this->input->post('password');

		    

			if ($this->ion_auth->login($email, $password)) {
				redirect(base_url() . 'index.php/Hod');
			} else {
				redirect(base_url() . 'index.php/User/hod_login');
			}
		}
	


    public function dashboard($error = NULL){

        if($this->ion_auth->logged_in()){
            if (!$this->ion_auth->is_admin()){
                redirect(base_url() . 'index.php/Admin');
            }

            $id = $this->ion_auth->get_user_id();
            $this->load->model('Users');
			$this->load->model('ion_auth_model');
            $this->db->select("*");
            $this->db->from("users");
            $this->db->join("users_groups","users.id = user_id");

            $this->db->where("group_id = 2 and user_id != $id");
            $data['users'] = $this->db->get()->result_object();

            $this->load->view('admin/header');
            $this->load->view('admin/users',$data);
            $this->load->view('admin/footer');
        }else{
            $this->index();
        }

    }

    public function add(){
        if($this->ion_auth->logged_in()) {
            $f_name = $this->input->post('f_name');
            $l_name = $this->input->post('l_name');
            $email = $this->input->post('email');
            $password = $this->input->post('password');
            $c_password = $this->input->post('c_password');
            $additional_data = array(
                'first_name' => $f_name,
                'last_name' => $l_name,
                'department' =>$this->input->post('department')
            );
            if ($password == $c_password) {
                $group = array('2'); // Sets user to admin.
                $this->ion_auth->register('', $password, $email, $additional_data, $group);
                redirect(base_url() . 'index.php/User/dashboard');
            } else {
                redirect(base_url() . 'index.php/User/dashboard');
            }
        }else{
            $this->index();
        }
    }
    public function delete($id){
        if($this->ion_auth->logged_in()) {
            $this->ion_auth->delete_user($id);
            redirect(base_url() . 'index.php/User/dashboard');
        }else{
            $this->index();
        }

    }

    public function search(){
        //Search by Name, Company Name, Industry, Institute, Course

    }
}
