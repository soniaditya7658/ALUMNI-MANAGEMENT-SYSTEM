<?php
class Academics extends MY_Model
{
    protected $_table_name = 'academics';
    protected $_primary_key = 'a_id';
    protected $_primary_filter = 'intval';
    protected $_order_by = '';
    public $rules = array();
    protected $_timestamp = '';

    function get_studies(){
        if ($this->ion_auth->is_admin()) {
            $query = $this->db->query("SELECT first_name, last_name, email, phone_no,college_name,field_of_study,start_year,end_year,degree from general_info RIGHT JOIN academics on general_info.user_id = academics.s_id");
        }else{
            $query = $this->db->query("SELECT first_name, last_name, email, phone_no,college_name,field_of_study,start_year,end_year,degree from general_info RIGHT JOIN academics on general_info.user_id = academics.s_id where general_info.course = '$this->course'");

        }
        return $query->result();
    }

	function get_studies_hod(){
		if ($this->ion_auth->in_group(2)) {
			$query = $this->db->query("SELECT first_name, last_name, email, phone_no,college_name,field_of_study,start_year,end_year,degree from general_info RIGHT JOIN academics on general_info.user_id = academics.s_id  ");
		}else{
			$query = $this->db->query("SELECT first_name, last_name, email, phone_no,college_name,field_of_study,start_year,end_year,degree from general_info RIGHT JOIN academics on general_info.user_id = academics.s_id where general_info.course = '$this->course'");

		}
		return $query->result();
	}

    function get_student_studies($id){
        $this->db->select("academics.*");
        $this->db->from("academics");
        $this->db->join("users","academics.s_id = users.id");
        $this->db->where("users.id = $id");
        $data = $this->db->get()->result_object();

        return $data;
    }
}
