<?php
class Business extends MY_Model
{
    protected $_table_name = 'business';
    protected $_primary_key = 'b_id';
    protected $_primary_filter = 'intval';
    protected $_order_by = '';
    public $rules = array();
    protected $_timestamp = '';

    function get_business(){
        if ($this->ion_auth->is_admin()) {
            $query = $this->db->query("SELECT first_name, last_name,turnover, email, phone_no,company_name,office_address,description,industry from general_info RIGHT JOIN business on general_info.user_id = business.s_id");
        }else{
            $query = $this->db->query("SELECT first_name, last_name,turnover, email, phone_no,company_name,office_address,description,industry from general_info RIGHT JOIN business on general_info.user_id = business.s_id where general_info.course = '$this->course'");

        }
        return $query->result();
    }

	function get_business_hod(){
		if ($this->ion_auth->in_group(2)) {
			$query = $this->db->query("SELECT first_name, last_name,turnover, email, phone_no,company_name,office_address,description,industry from general_info RIGHT JOIN business on general_info.user_id = business.s_id");
		}else{
			$query = $this->db->query("SELECT first_name, last_name,turnover, email, phone_no,company_name,office_address,description,industry from general_info RIGHT JOIN business on general_info.user_id = business.s_id where general_info.course = '$this->course'");

		}
		return $query->result();
	}

    function get_student_business($id){
        $this->db->select("business.*");
        $this->db->from("business");
        $this->db->join("users","business.s_id = users.id");
        $this->db->where("users.id = $id");
        $data = $this->db->get()->result_object();

        return $data;
    }

}
