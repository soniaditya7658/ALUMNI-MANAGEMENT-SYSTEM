<?php
class Events extends MY_Model
{
    protected $_table_name = 'events';
    protected $_primary_key = 'e_id';
    protected $_primary_filter = 'intval';
    protected $_order_by = '';
    public $rules = array();
    protected $_timestamp = '';

    public function add($e_name, $created_by, $description,$file, $image){
        //$e_name = "Taarangan";
        //$created_by = 2;
        $date_time = $this->getDatetimeNow();

       // $description = "Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum";
        $this->save(array(
            'e_name'=>$e_name,
            'created_by' => $created_by,
            'date_time' => $date_time,
            'description' => $description,
            'attach'=>$file,
            'photo'=>$image
        ));
    }

    public function remove($id){
        return $this->delete($id);
    }

    public function view($id = null){
        $this->db->select("first_name,last_name,department,e_name, e_id, created_by, date_time, events.description,photo, attach");
        $this->db->from("events");
        $this->db->join("users","events.created_by = users.id");

        if($id != null){
            $this->db->where("users.id = $id");
        }
        $events =$this->db->get()->result_object();
        return $events;
    }
    public function edit($id){

    }

    public function get_events($id){
        $this->db->select("first_name,last_name,department,e_name, e_id, created_by, date_time, events.description,photo, attach");
        $this->db->from("events");
        $this->db->join("users","events.created_by = users.id");

        $events =$this->db->get()->result_object();

        $this->load->model('Events_data');
        $events_data = $this->Events_data->get_by(array("user"=>$id), FALSE);

    }
}