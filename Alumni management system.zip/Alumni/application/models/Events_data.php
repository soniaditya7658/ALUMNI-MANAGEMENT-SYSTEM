<?php
class Events_data extends MY_Model
{
    protected $_table_name = 'events_data';
    protected $_primary_key = 'ed_id';
    protected $_primary_filter = 'intval';
    protected $_order_by = '';
    public $rules = array();
    protected $_timestamp = '';

    public function status(){
        $id = 1;
        $status = $this->input->post('status');
        $event_id = $this->input->post('id');

        $r_id = $this->Events_data->save(array(
            'event' => $event_id,
            'user' => $id,
            'status' => $status
        ));
        if($r_id != ''){
            echo "attending";
        }

    }
}
