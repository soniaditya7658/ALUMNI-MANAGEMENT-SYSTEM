<?php
class Feedbacks extends MY_Model{

    public function add($id,$answer){

        foreach($answer as $ans){
            $data = array(
                'user_id'=>$id,
                'answer'=>$ans
            );

            $this->db->insert('answers',$data);
        }

    }

    public function check($id,$total){
        $this->db->select('*');
        $this->db->from('answers');
        $this->db->where("user_id = $id");
        $result = $this->db->get()->result_object();
        //var_dump($result);
        if(count($result) == $total){
            return true;
        }else{
            return false;
        }
    }
}