<?php
class General_Info extends MY_Model
{
    protected $_table_name = 'general_info';
    protected $_primary_key = 's_id';
    protected $_primary_filter = 'intval';
    protected $_order_by = '';
    public $rules = array();
    protected $_timestamp = '';

    function get_basic(){
        if ($this->ion_auth->is_admin())
        {
            $query = $this->db->query("SELECT * from general_info");
        }else{
            $query = $this->db->query("SELECT * from general_info where course = '$this->course'");
        }

        return $query->result();
    }

	function get_basic_hod(){
		if ($this->ion_auth->in_group(2))
		{
			$query = $this->db->query("SELECT * from general_info");
		}else{
			$query = $this->db->query("SELECT * from general_info where course = '$this->course'");
		}

		return $query->result();
	}

    function get_courses(){
        $this->db->distinct();
        $this->db->select('course');
        $this->db->from('general_info');
        return $this->db->get()->result_object();
    }

    function total_members(){
        $this->load->library('ion_auth');
        if($this->ion_auth->is_admin()){
            return $this->db->count_all('general_info');
        }else{
            return count($this->get_by(array('course'=>$this->course),FALSE));
        }

    }

	function total_members_hod(){
		$this->load->library('ion_auth');
		if($this->ion_auth->in_group(2)){
			return $this->db->count_all('general_info');
		}else{
			return count($this->get_by(array('course'=>$this->course),FALSE));
		}

	}

    function get_student_info($id){
        $this->db->select("general_info.*, general_info.image as image");
        $this->db->from('general_info');
        $this->db->join('users', 'general_info.user_id = users.id');
        $this->db->where("user_id = $id");
        $data = $this->db->get()->result_object();
		if(count($data) > 0){
			 return $data[0];
		}else{
			return 0;
		}
       
    }

}
