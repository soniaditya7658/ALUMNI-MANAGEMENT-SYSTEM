<?php
class Jobs extends MY_Model
{
    protected $_table_name = 'jobs';
    protected $_primary_key = 'j_id';
    protected $_primary_filter = 'intval';
    protected $_order_by = '';
    public $rules = array();
    protected $_timestamp = '';

    public function companies(){
        //get a list of companies
    }
    function get_jobs(){
        if ($this->ion_auth->is_admin()){
            $query = $this->db->query("SELECT first_name, last_name, email, phone_no,company_name,position,ctc,placement_type,start_year,end_year,industry from general_info JOIN jobs on general_info.user_id = jobs.s_id");

        }else{
            $query = $this->db->query("SELECT first_name, last_name, email, phone_no,company_name,position,ctc,placement_type,start_year,end_year,industry from general_info JOIN jobs on general_info.user_id = jobs.s_id where general_info.course = '$this->course'");

        }

        return $query->result();
    }

	function get_jobs_hod(){
		if ($this->ion_auth->in_group(2)){
			$query = $this->db->query("SELECT first_name, last_name, email, phone_no,company_name,position,ctc,placement_type,start_year,end_year,industry from general_info JOIN jobs on general_info.user_id = jobs.s_id");

		}else{
			$query = $this->db->query("SELECT first_name, last_name, email, phone_no,company_name,position,ctc,placement_type,start_year,end_year,industry from general_info JOIN jobs on general_info.user_id = jobs.s_id where general_info.course = '$this->course'");

		}

		return $query->result();
	}


    public function industry($industry){
        return($this->get_by(array("industy"=>$industry),FALSE)->result_object());
    }

    function get_industries(){
        $this->db->distinct();
        $this->db->select('Industry');
        $this->db->from('Jobs');
        return $this->db->get()->result_object();

    }

    public function get_student_jobs($id){
        $this->db->select("jobs.*");
        $this->db->from("jobs");
        $this->db->join("users","jobs.s_id = users.id");
        $this->db->where("users.id = $id");
        $data = $this->db->get()->result_object();

        return $data;
    }
}
