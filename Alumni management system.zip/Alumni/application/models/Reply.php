<?php

class Reply extends MY_Model
{
    protected $_table_name = 'responses';
    protected $_primary_key = 'r_id';
    protected $_primary_filter = 'intval';
    protected $_order_by = '';
    public $rules = array();
    protected $_timestamp = '';


}