<?php
class Requests extends MY_Model
{
    protected $_table_name = 'requests';
    protected $_primary_key = 'r_id';
    protected $_primary_filter = 'intval';
    protected $_order_by = '';
    public $rules = array();
    protected $_timestamp = '';

    public function add($title, $user_id, $request,$file){

        $this->save(array(
            'title'=>$title,
            'user_id'=>$user_id,
            'date_time'=>$this->getDatetimeNow(),
            'description'=>$request,
            'attach'=>$file
        ));
    }


    public function view($id = null){

        $this->db->select("first_name,last_name,department,title, r_id, user_id, date_time, description,attach");
        $this->db->from("requests");
        $this->db->join("users","requests.user_id = users.id");
        if($id != null){
            $this->db->where("users.id = $id");
        }
        $requests =$this->db->get()->result_object();
        return $requests;
    }


    public function respond($req_id){
        $user_id = 2;
        $respond = "SomeRespond";

        $this->save(array(
            'user_id'=>$user_id,
            'text' => $respond,
            'req_id' => $req_id
        ));
    }

    public function edit(){

    }


}