<?php


class Responses extends MY_Model
{
    protected $_table_name = 'responses';
    protected $_primary_key = 'r_id';
    protected $_primary_filter = 'intval';
    protected $_order_by = '';
    public $rules = array();
    protected $_timestamp = '';

    function view($request){
        $this->db->select("first_name,last_name,r_id,req_id,text,user_id");
        $this->db->from("responses");
        $this->db->join("users","responses.user_id = users.id");
        $responses =$this->db->get()->result_object();
        return $responses;
    }
}