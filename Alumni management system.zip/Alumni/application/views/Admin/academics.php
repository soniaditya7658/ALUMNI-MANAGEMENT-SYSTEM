<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">

        <div class = "row">
            <div class="col-md-12">
                <div class="box box-success">
                    <div class="box-header with-border">
                        <h3 class="box-title">General Database</h3>

                        <!-- /.box-tools -->
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <div class = "quick_search">
                            <table id="example1" class="table table-bordered table-hover">
                                <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Phone No</th>
                                    <th>Email</th>
                                    <th>College Name</th>
                                    <th>Field Of Study</th>
                                    <th>Start Year</th>
                                    <th>End Year</th>
                                    <th>Degree</th>


                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach($information as $info): ?>
                                    <tr>

                                        <td><?php echo $info->first_name . ' ' . $info->last_name; ?></td>
                                        <td><?php echo $info->phone_no; ?></td>
                                        <td><?php echo $info->email; ?></td>
                                        <td><?php echo $info->college_name; ?></td>
                                        <td><?php echo $info->field_of_study; ?></td>
                                        <td><?php echo $info->start_year; ?></td>
                                        <td><?php echo $info->end_year; ?></td>
                                        <td><?php echo $info->degree; ?></td>


                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>

    </section>
</div>