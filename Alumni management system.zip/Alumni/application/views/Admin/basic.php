<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">

        <div class = "row">
            <div class="col-md-12">
                <div class="box box-success">
                    <div class="box-header with-border">
                        <h3 class="box-title">General Database</h3>

                        <!-- /.box-tools -->
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <div class = "quick_search">
                            <table id="example1" class="table table-bordered table-hover">
                                <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Phone No</th>
                                    <th>Email</th>
                                    <th>Passed Year</th>
                                    <th>Gender</th>
                                    <th>M Name | F Name</th>
                                    <th>DOB</th>
                                    <th>Address</th>
                                    <th>UID</th>
                                    <th>Course</th>
                                    <th>Passed Year</th>
                                    <th>Avg Percentage</th>

                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach($information as $info): ?>
                                    <tr>

                                        <td><?php echo $info->first_name . ' ' . $info->last_name; ?></td>
                                        <td><?php echo $info->phone_no; ?></td>
                                        <td><?php echo $info->email; ?></td>
                                        <td><?php echo $info->passed_year; ?></td>
                                        <td><?php echo $info->gender; ?></td>
                                        <td><?php echo $info->mothers_name . '|' . $info->fathers_name; ?></td>
                                        <td><?php echo $info->date_of_birth; ?></td>
                                        <td><?php echo $info->address; ?></td>
                                        <td><?php echo $info->uid; ?></td>
                                        <td><?php echo $info->course; ?></td>
                                        <td><?php echo $info->passed_year; ?></td>
                                        <td><?php echo $info->average_percentage; ?></td>


                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>

    </section>
</div>