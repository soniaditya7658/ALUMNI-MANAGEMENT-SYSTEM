<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <!-- Add new Requests -->


        <!-- End of Add new Request -->

        <div class = "row">
            <br>
            <div class="col-md-12">
                <div class="box box-success">
                    <div class="box-header with-border">
                        <h3 class="box-title">Send Email Newsletters</h3>
                        <form action = "<?php echo base_url() . 'index.php/Email/send' ?>" method = "get">
                            <label>Subject: </label>
                            <input type = "text" name = "subject" class = "form-control">

<br>
                            <label for = "body">Body: </label>
                            <textarea name = "body" class = "form-control"></textarea>
<br>
                            <input class = "btn btn-primary" type = "submit" name = "submit" value = "Send">
                        </form>
                    </div>
                </div>

            </div>

    </section>
</div>