<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <!-- Add new Requests -->
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Add New Event</button>


        <div id="myModal" class="modal fade" role="dialog">
            <div class="modal-dialog">

                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Add new Event</h4>
                    </div>
                    <div class="modal-body">
                        <form action = "<?php echo base_url() . 'index.php/Event/add' ?>" method = "Post" enctype="multipart/form-data">

                            <label for = "title">Event Name: </label>
                            <input type = "text" name = "title" class = "form-control">

                            <label for = "description">Description: </label>
                            <textarea class = "form-control" name = "description"></textarea>

                            Image: <input type = "file" name = "userfile" size = "20">

                            Attachment: <input type = "file" name = "imagefile" size="20">


                    </div>
                    <div class="modal-footer">
                        <input type = "submit" name = "submit" value = "Add" class = "btn btn-primary">
                        </form>
                    </div>
                </div>

            </div>
        </div>

        <!-- End of Add new Request -->

        <div class = "row">
            <br>
            <div class="col-md-12">
                <div class="box box-success">
                    <div class="box-header with-border">
                        <h3 class="box-title">Events</h3>

                        <!-- /.box-tools -->
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <div class = "quick_search">
                            <table id="example1" class="table table-bordered table-hover">
                                <thead>
                                <tr>
                                    <th>Event Name</th>
                                    <th>Created By:</th>
                                    <th>Date Time</th>
                                    <th>Description</th>
                                    <th>Photo</th>
                                    <th>Attachment</th>
                                    <th>Customize</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach($events as $event): ?>
                                    <tr>

                                        <td><?php echo $event->e_name; ?></td>
                                        <td><?php echo $event->first_name . ' ' . $event->last_name; ?></td>
                                        <td><?php echo $event->date_time; ?></td>
                                        <td><?php echo $event->description; ?></td>
                                        <td><a href = "<?php echo base_url() . 'uploads/' . $event->photo;?>" target="_blank"><?php echo $event->photo; ?></a></td>
                                        <td><a href = "<?php echo base_url() . 'uploads/' . $event->attach;?>" target="_blank"><?php echo $event->attach; ?></a></td>

                                        <td>
                                            <a href = "">Responses</a>
                                            <a href = "<?php echo base_url() . 'index.php/Event/delete/' . $event->e_id; ?>"><i class = "fa fa-trash-o"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>

    </section>
</div>