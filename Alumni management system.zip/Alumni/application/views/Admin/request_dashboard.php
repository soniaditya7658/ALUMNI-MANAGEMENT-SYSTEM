<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <!-- Add new Requests -->
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Add New Request</button>


        <div id="myModal" class="modal fade" role="dialog">
            <div class="modal-dialog">

                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Add new Request</h4>
                    </div>
                    <div class="modal-body">
                        <form action = "<?php echo base_url() . 'index.php/Request/add' ?>" method = "Post" enctype="multipart/form-data">

                            <label for = "title">Title: </label>
                            <input type = "text" name = "title" class = "form-control">

                            <label for = "description">Description: </label>
                            <textarea class = "form-control" name = "description"></textarea>

                            <input type = "file" name = "userfile" size = "20" />


                    </div>
                    <div class="modal-footer">
                        <input type = "submit" name = "submit" value = "Add" class = "btn btn-primary">
                        </form>
                    </div>
                </div>

            </div>
        </div>

        <!-- End of Add new Request -->

        <div class = "row">
            <br>
            <div class="col-md-12">
                <div class="box box-success">
                    <div class="box-header with-border">
                        <h3 class="box-title">Requests</h3>

                        <!-- /.box-tools -->
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <div class = "quick_search">
                            <table id="example1" class="table table-bordered table-hover">
                                <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Request By:</th>
                                    <th>Date Time</th>
                                    <th>Description</th>
                                    <th>File</th>
                                    <th>Customize</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach($requests as $request): ?>
                                    <tr>

                                        <td><?php echo $request->title; ?></td>
                                        <td><?php echo $request->first_name . ' ' . $request->last_name; ?></td>
                                        <td><?php echo $request->date_time; ?></td>
                                        <td><?php echo $request->description; ?></td>
                                        <td><a href = "<?php echo base_url() . 'uploads/' . $request->attach;?>" target="_blank"><?php echo $request->attach; ?></a></td>
                                        <td>
                                            <a href = "<?php echo base_url() . 'index.php/Admin/response/' . $request->r_id; ?>">View Responses </a>
                                            <a href = "<?php echo base_url() . 'index.php/Request/delete/' . $request->r_id; ?>"><i class = "fa fa-trash-o"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>

    </section>
</div>