<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">

        <div class = "row">
            <div class="col-md-12">
                <div class="box box-success">
                    <div class="box-header with-border">
                        <h3 class="box-title">Response for: <?php $request->title; ?></h3>

                        <!-- /.box-tools -->
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <div class = "quick_search">
                            <table id="example1" class="table table-bordered table-hover">
                                <thead>
                                <tr>
                                    <th>Response</th>
                                    <th>User</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach($responses as $response): ?>
                                    <tr>

                                        <td><?php echo $response->text; ?></td>
                                        <td><?php echo $response->first_name . ' ' . $response->last_name; ?></td>

                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>

    </section>
</div>