<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <!-- Trigger the modal with a button -->
        <button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal">Add HOD</button>

        <!-- Modal -->
        <div id="myModal" class="modal fade" role="dialog">
            <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Add HOD</h4>
                    </div>
                    <div class="modal-body">
                        <form action ="<?php echo base_url(). 'index.php/User/add' ?>" method = "POST">
                            <label for = "f_name">First Name: </label>
                            <input type = "text" name = "f_name" class = "form-control">

                            <label for = "l_name">Last Name: </label>
                            <input type = "text" name = "l_name" class = "form-control">

                            <label for = "email">Email: </label>
                            <input type = "email" name = "email" class = "form-control">

                            <label for = "department">Department: </label>
                            <select name = "department" class="form-control">
                                <option value = "Botany">Botany</option>
                                <option value = "Chemistry">Chemistry</option>
                                <option value = "Physics">Physics</option>
                                <option value = "Bio-Tech">Bio-Tech</option>
                                <option value = "Zoology">Zoology</option>
                                <option value = "BSC Computer Science">BSC Computer Science</option>
                                <option value = "BSC IT">BSC IT</option>
                                <option value = "Science Maths">Science Maths</option>
                                <option value = "BSC Aviation">BSC Aviation</option>
                                <option value = "Human Science">Human Science</option>
                                <option value = "Economics">Economics</option>
                                <option value = "Accounts">Accounts</option>
                                <option value = "Commerce Maths">Commerce Maths</option>
                                <option value = "EVS">EVS</option>
                                <option value = "FC">FC</option>
                                <option value = "Business Communication">Business Communication</option>
                                <option value = "Business Law">Business Law</option>
                                <option value = "Commerce">Commerce</option>
                                <option value = "Financial Market">Financial Market</option>
                                <option value = "BMS">BMS</option>
                                <option value = "Banking and Insurance">Banking and Insurance</option>
                                <option value = "BIM">BIM</option>
                                <option value = "Accounting Finance">Accounting Finance</option>
                                <option value = "BMM">BMM</option>
                                <option value = "Human Science">Human Science</option>
                            </select>

                            <label for = "password">Password: </label>
                            <input type = "password" name = "password" class = "form-control">

                            <label for="c_password">Confirm Password: </label>
                            <input type = "password" name = "c_password" class = "form-control">
<br>
                            <input type = "submit" name = "submit" value = "Add" class = "btn btn-info">
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>

            </div>
        </div>
        <br><br>
        <div class = "row">
            <div class="col-md-12">
                <div class="box box-success">
                    <div class="box-header with-border">
                        <h3 class="box-title">HOD's Database</h3>

                        <!-- /.box-tools -->
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <div class = "quick_search">
                            <table id="example1" class="table table-bordered table-hover">
                                <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Department</th>
                                    <th>Customize</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach($users as $user): ?>
                                    <tr>

                                        <td><?php echo $user->first_name . ' ' . $user->last_name; ?></td>
                                        <td><?php echo $user->email; ?></td>
                                        <td><?php echo $user->department; ?></td>
                                        <td><a href="<?php echo base_url() . 'index.php/User/delete/' . $user->user_id; ?>"><i class = "fa fa-trash"></i></a></td>

                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>

    </section>
</div>