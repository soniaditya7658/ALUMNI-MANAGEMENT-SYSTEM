<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Thakur College Alumni Network</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="http://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="http://code.jquery.com/jquery-3.2.1.min.js" integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4=" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/parsley.js/2.7.2/parsley.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <style>
        .form-inline input{
            width:98% !important;
        }
        .form-inline .form-group{
            width:33%;
        }
    </style>
</head>
<body>
<!-- page content -->


<?php if(isset($_GET['success'])){ ?>
    <div class = "panel panel-primary">
        <div class = "panel-body">We got your Information. Thank you for registering!</div>
    </div>
<?php
}
?>
<div class="row setup-content" id="step-1">
    <div class="col-xs-12">
        <div class="col-md-12 well">
            <h1 class = "text-center"> General Information</h1>

            <!-- <form> -->

            <form id = "personal-info" action="<?php echo base_url() . 'index.php/Alumni/register' ?>" method = "POST">
                <div class = "form-inline">
                    <div class="form-group" style = "width:33%;"> <!-- First Name -->
                        <label for="first_name" class="control-label">First Name</label><br>
                        <input required type="text" class="form-control" id="first_name_id" name="first_name" placeholder="John">
                    </div>
                    <div class="form-group"> <!-- Middle Name -->
                        <label for="last_name" class="control-label">Middle Name</label><br>
                        <input type="text" class="form-control" id="middle_name_id" name="middle_name" placeholder="Ron">
                    </div>
                    <div class="form-group"> <!-- Last Name -->
                        <label for="last_name" class="control-label">Last Name</label><br>
                        <input required type="text" class="form-control" id="last_name_id" name="last_name" placeholder="Doe">
                    </div>
                </div>


                <div class="form-group"> <!-- Gender -->
                    <label for="street1_id" class="control-label">Gender</label>
                    <div class="radio">
                        <label>
                            <input type="radio" name="gender" value="male" checked>
                            Male
                        </label>
                    </div>
                    <div class="radio">
                        <label>
                            <input type="radio" name="gender" value="female">
                            Female
                        </label>
                    </div>
                </div>

                <div class="form-group"> <!-- Mothers Name -->
                    <label for="mothers_name" class="control-label">Mothers Name: </label>
                    <input required type="text" class="form-control" name="mothers_name" placeholder="">
                </div>

                <div class="form-group"> <!-- Fathers Name -->
                    <label for="fathers_name" class="control-label">Fathers Name: </label>
                    <input required type="text" class="form-control" name="fathers_name" placeholder="">
                </div>

                <div class="form-group"> <!-- Date of Birth -->
                    <label for="dob" class="control-label">Date of Birth</label>
                    <input required type="text" id = "dob" class="form-control" name="dob">
                </div>

                <div class="form-group"> <!-- Address -->
                    <label for="address" class="control-label">Address</label>
                    <textarea required class = "form-control" name = "address"></textarea>
                </div>

                <div class="form-group"> <!-- Phone No-->
                    <label for="phone" class="control-label">Phone No</label>
                    <input required type="text" class="form-control" name="phone" placeholder="9876543210">
                </div>

                <div class="form-group"> <!-- Email Id -->
                    <label for="email" class="control-label">Email Id</label>
                    <input required type="email" class="form-control" name="email" placeholder="johndoe@gmail.com">
                </div>

                <div class="form-group"> <!-- UID-->
                    <label for="uid" class="control-label">UID: </label>
                    <input required type="text" class="form-control" name="uid" >
                </div>

                <div class="form-group"> <!-- course-->
                    <label for="course" class="control-label">Course: </label>
                    <select name="course" class="form-control">
                        <option value="Botany">Botany</option>
                        <option value="Chemistry">Chemistry</option>

                        <option value="Physics">Physics</option>

                        <option value="Bio-technology">Bio-technology</option>

                        <option value="Zoology">Zoology</option>

                        <option value="BSc Computer Science">BSc Computer Science</option>

                        <option value="BSc Information Technology">BSc Information Technology</option>

                        <option value="BSc Maths">BSc Maths</option>

                        <option value="BSc Aviation">BSc Aviation</option>

                        <option value="BSc Human Science">BSc Human Science</option>

                        <option value="Economics">Economics</option>

                        <option value="Accounts">Accounts</option>

                        <option value="BCom Maths">BCom Maths</option>

                        <option value="Business Communication">Business Communication</option>

                        <option value="Commerce">Commerce</option>

                        <option value="Business Law">Business Law</option>

                        <option value="Financial Market">Financial Market</option>

                        <option value="BMS">BMS</option>

                        <option value="Banking and Insurance">Banking and Insurance</option>

                        <option value="BIM">BIM</option>

                        <option value="Accounting Finance">Accounting Finance</option>

                        <option value="BMM">BMM</option>

                        <option value="BCom Human Science">BCom Human Science</option>

                    </select>
                </div>

                <div class="form-group"> <!-- course-->
                    <label for="passed_year" class="control-label">Passed Year: </label>
                    <input required type="text" class="form-control" name="passed_year" >
                </div>

                <div class="form-group"> <!-- avg Percent-->
                    <label for="avg_percent" class="control-label">Average Percentage: </label>
                    <input required type="text" class="form-control" name="avg_percent" >
                </div>

                <div class="form-group"> <!-- Gender -->
                    <label for="current" class="control-label">Current</label>
                    <div class="radio">
                        <label>
                            <input class = "current" type="radio" name="current" value="job" checked>
                            Job
                        </label>
                    </div>
                    <div class="radio">
                        <label>
                            <input class = "current" type="radio" name="current" value="studies">
                            Further Studies
                        </label>
                    </div>
                    <div class="radio">
                        <label>
                            <input class = "current" type="radio" name="current" value="business">
                            Business
                        </label>
                    </div>
                </div>
                <hr>
                <!---    Job    --->

                <div class = "job_form">
                    <h1 class = "text-center">Job Information</h1>

                    <div class="form-group"> <!-- Company Name -->
                        <label for="jcompany" class="control-label">Company Name: </label>
                        <input type="text" class="form-control" id = "company" name="jcompany" placeholder="">
                    </div>

                    <div class="form-group"> <!-- Position -->
                        <label for="jposition" class="control-label">Position: </label>
                        <input type="text" class="form-control" name="jposition" placeholder="">
                    </div>

                    <div class="form-group"> <!-- CTC -->
                        <label for="jctc" class="control-label">CTC(Cost to Company): </label>
                        <input type="text" class="form-control" name="jctc" placeholder="">
                    </div>

                    <div class="form-group"> <!-- Placement Type -->
                        <label for="jplacement_type" class="control-label">Placement Type: </label>
                        <select class = "form-control" name = "jplacement_type">
                            <option value = "College Placement">College Placement</option>
                            <option value = "Walk-In Interview">Walk-in Interview</option>
                        </select>

                    </div>

                    <div class="form-group"> <!-- Industry -->
                        <label for="jindustry" class="control-label">Industry: </label>
                        <select name="jindustry" class="form-control">
                            <option value="Accounting">Accounting</option>

                            <option value="Airlines/Aviation">Airlines/Aviation</option>

                            <option value="Alternative Dispute Resolution">Alternative Dispute Resolution</option>

                            <option value="Alternative Medicine">Alternative Medicine</option>

                            <option value="Animation">Animation</option>

                            <option value="Apparel & Fashion">Apparel & Fashion</option>

                            <option value="Architecture & Planning">Architecture & Planning</option>

                            <option value="Arts and Crafts">Arts and Crafts</option>

                            <option value="Automotive">Automotive</option>

                            <option value="Aviation & Aerospace">Aviation & Aerospace</option>

                            <option value="Banking">Banking</option>

                            <option value="Biotechnology">Biotechnology</option>

                            <option value="Broadcast Media">Broadcast Media</option>

                            <option value="Building Materials">Building Materials</option>

                            <option value="Business Supplies and Equipment">Business Supplies and Equipment</option>

                            <option value="Capital Markets">Capital Markets</option>

                            <option value="Chemicals">Chemicals</option>

                            <option value="Civic & Social Organization">Civic & Social Organization</option>

                            <option value="Civil Engineering">Civil Engineering</option>

                            <option value="Commercial Real Estate">Commercial Real Estate</option>

                            <option value="Computer & Network Security">Computer & Network Security</option>

                            <option value="Computer Games">Computer Games</option>

                            <option value="Computer Hardware">Computer Hardware</option>

                            <option value="Computer Networking">Computer Networking</option>

                            <option value="Computer Software">Computer Software</option>

                            <option value="Construction">Construction</option>

                            <option value="Consumer Electronics">Consumer Electronics</option>

                            <option value="Consumer Goods">Consumer Goods</option>

                            <option value="Consumer Services">Consumer Services</option>

                            <option value="Cosmetics">Cosmetics</option>

                            <option value="Dairy">Dairy</option>

                            <option value="Defense & Space">Defense & Space</option>

                            <option value="Design">Design</option>

                            <option value="Education Management">Education Management</option>

                            <option value="E-Learning">E-Learning</option>

                            <option value="Electrical/Electronic Manufacturing">Electrical/Electronic Manufacturing</option>

                            <option value="Entertainment">Entertainment</option>

                            <option value="Environmental Services">Environmental Services</option>

                            <option value="Events Services">Events Services</option>

                            <option value="Executive Office">Executive Office</option>

                            <option value="Facilities Services">Facilities Services</option>

                            <option value="Farming">Farming</option>

                            <option value="Financial Services">Financial Services</option>

                            <option value="Fine Art">Fine Art</option>

                            <option value="Fishery">Fishery</option>

                            <option value="Food & Beverages">Food & Beverages</option>

                            <option value="Food Production">Food Production</option>

                            <option value="Fund-Raising">Fund-Raising</option>

                            <option value="Furniture">Furniture</option>

                            <option value="Gambling & Casinos">Gambling & Casinos</option>

                            <option value="Glass, Ceramics & Concrete">Glass, Ceramics & Concrete</option>

                            <option value="Government Administration">Government Administration</option>

                            <option value="Government Relations">Government Relations</option>

                            <option value="Graphic Design">Graphic Design</option>

                            <option value="Health, Wellness and Fitness">Health, Wellness and Fitness</option>

                            <option value="Higher Education">Higher Education</option>

                            <option value="Hospital & Health Care">Hospital & Health Care</option>

                            <option value="Hospitality">Hospitality</option>

                            <option value="Human Resources">Human Resources</option>

                            <option value="Import and Export">Import and Export</option>

                            <option value="Individual & Family Services">Individual & Family Services</option>

                            <option value="Industrial Automation">Industrial Automation</option>

                            <option value="Information Services">Information Services</option>

                            <option value="Information Technology and Services">Information Technology and Services</option>

                            <option value="Insurance">Insurance</option>

                            <option value="International Affairs">International Affairs</option>

                            <option value="International Trade and Development">International Trade and Development</option>

                            <option value="Internet">Internet</option>

                            <option value="Investment Banking">Investment Banking</option>

                            <option value="Investment Management">Investment Management</option>

                            <option value="Judiciary">Judiciary</option>

                            <option value="Law Enforcement">Law Enforcement</option>

                            <option value="Law Practice">Law Practice</option>

                            <option value="Legal Services">Legal Services</option>

                            <option value="Legislative Office">Legislative Office</option>

                            <option value="Leisure, Travel & Tourism">Leisure, Travel & Tourism</option>

                            <option value="Libraries">Libraries</option>

                            <option value="Logistics and Supply Chain">Logistics and Supply Chain</option>

                            <option value="Luxury Goods & Jewelry">Luxury Goods & Jewelry</option>

                            <option value="Machinery">Machinery</option>

                            <option value="Management Consulting">Management Consulting</option>

                            <option value="Maritime">Maritime</option>

                            <option value="Market Research">Market Research</option>

                            <option value="Marketing and Advertising">Marketing and Advertising</option>

                            <option value="Mechanical or Industrial Engineering">Mechanical or Industrial Engineering</option>

                            <option value="Media Production">Media Production</option>

                            <option value="Medical Devices">Medical Devices</option>

                            <option value="Medical Practice">Medical Practice</option>

                            <option value="Mental Health Care">Mental Health Care</option>

                            <option value="Military">Military</option>

                            <option value="Mining & Metals">Mining & Metals</option>

                            <option value="Motion Pictures and Film">Motion Pictures and Film</option>

                            <option value="Museums and Institutions">Museums and Institutions</option>

                            <option value="Music">Music</option>

                            <option value="Nanotechnology">Nanotechnology</option>

                            <option value="Newspapers">Newspapers</option>

                            <option value="Non-Profit Organization Management">Non-Profit Organization Management</option>

                            <option value="Oil & Energy">Oil & Energy</option>

                            <option value="Online Media">Online Media</option>

                            <option value="Outsourcing/Offshoring">Outsourcing/Offshoring</option>

                            <option value="Package/Freight Delivery">Package/Freight Delivery</option>

                            <option value="Packaging and Containers">Packaging and Containers</option>

                            <option value="Paper & Forest Products">Paper & Forest Products</option>

                            <option value="Performing Arts">Performing Arts</option>

                            <option value="Pharmaceuticals">Pharmaceuticals</option>

                            <option value="Philanthropy">Philanthropy</option>

                            <option value="Photography">Photography</option>

                            <option value="Plastics">Plastics</option>

                            <option value="Political Organization">Political Organization</option>

                            <option value="Primary/Secondary Education">Primary/Secondary Education</option>

                            <option value="Printing">Printing</option>

                            <option value="Professional Training & Coaching">Professional Training & Coaching</option>

                            <option value="Program Development">Program Development</option>

                            <option value="Public Policy">Public Policy</option>

                            <option value="Public Relations and Communications">Public Relations and Communications</option>

                            <option value="Public Safety">Public Safety</option>

                            <option value="Publishing">Publishing</option>

                            <option value="Railroad Manufacture">Railroad Manufacture</option>

                            <option value="Ranching">Ranching</option>

                            <option value="Real Estate">Real Estate</option>

                            <option value="Recreational Facilities and Services">Recreational Facilities and Services</option>

                            <option value="Religious Institutions">Religious Institutions</option>

                            <option value="Renewables & Environment">Renewables & Environment</option>

                            <option value="Research">Research</option>

                            <option value="Restaurants">Restaurants</option>

                            <option value="Retail">Retail</option>

                            <option value="Security and Investigation">Security and Investigations</option>

                            <option value="Semiconductors">Semiconductors</option>

                            <option value="Shipbuilding">Shipbuilding</option>

                            <option value="Sporting Goods">Sporting Goods</option>

                            <option value="Sports">Sports</option>

                            <option value="Staffing and Recruiting">Staffing and Recruiting</option>

                            <option value="Supermarkets">Supermarkets</option>

                            <option value="Telecommunications">Telecommunications</option>

                            <option value="Textiles">Textiles</option>

                            <option value="Think Tanks">Think Tanks</option>

                            <option value="Tobacco">Tobacco</option>

                            <option value="Translation and Localization">Translation and Localization</option>

                            <option value="Transportation/Trucking/Railroad">Transportation/Trucking/Railroad</option>

                            <option value="Utilities">Utilities</option>

                            <option value="Venture Capital & Private Equity">Venture Capital & Private Equity</option>

                            <option value="Veterinary">Veterinary</option>

                            <option value="Warehousing">Warehousing</option>

                            <option value="Wholesale">Wholesale</option>

                            <option value="Wine and Spirits">Wine and Spirits</option>

                            <option value="Wireless">Wireless</option>

                            <option value="Writing and Editing">Writing and Editing</option>


                        </select>

                    </div>

                    <div class="form-group"> <!-- Start Date -->
                        <label for="jstart_date" class="control-label">Start Year: </label>
                        <input type="text" class="form-control" name="jstart_date" placeholder="">
                    </div>

                </div>

                <!---    Further Studies    -->
                <div class = "studies_form">
                    <h1 class = "text-center">Further studies</h1>
                    <div class="form-group"> <!-- College Name -->
                        <label for="fcollege" class="control-label">College Name: </label>
                        <input type="text" class="form-control" name="fcollege" placeholder="">
                    </div>

                    <div class="form-group"> <!-- Degree -->
                        <label for="fdegree" class="control-label">Master Degree or PHD: </label>
                        <input type="text" class="form-control" name="fdegree" placeholder="">
                    </div>

                    <div class="form-group"> <!-- Field Of Study -->
                        <label for="ffield_of_study" class="control-label">Field of Study: </label>
                        <input type="text" class="form-control" name="ffield_of_study" placeholder="">
                    </div>

                    <div class="form-group"> <!-- Start Year -->
                        <label for="fstart_date" class="control-label">Start Year: </label>
                        <input type="text" class="form-control" name="fstart_year" placeholder="">
                    </div>

                    <div class="form-group"> <!-- End Year -->
                        <label for="fend_date" class="control-label">End Year: </label>
                        <input type="text" class="form-control" name="fend_year" placeholder="">
                    </div>

                </div>

                <!---    Business    --->
                <div class="business_form">
                    <h1 class = "text-center">Business</h1>

                    <div class="form-group"> <!-- Company Name -->
                        <label for="bcompany" class="control-label">Company Name: </label>
                        <input type="text" class="form-control" name="bcompany" placeholder="">
                    </div>

                    <div class="form-group"> <!-- Office Address -->
                        <label for="baddress" class="control-label">Office Address: </label>
                        <textarea class = "form-control" name = "baddress"></textarea>
                    </div>

                    <div class="form-group"> <!-- Industry -->
                        <label for="bindustry" class="control-label">Industry: </label>
                        <select name="bindustry" class="form-control">
                            <option value="Accounting">Accounting</option>

                            <option value="Airlines/Aviation">Airlines/Aviation</option>

                            <option value="Alternative Dispute Resolution">Alternative Dispute Resolution</option>

                            <option value="Alternative Medicine">Alternative Medicine</option>

                            <option value="Animation">Animation</option>

                            <option value="Apparel & Fashion">Apparel & Fashion</option>

                            <option value="Architecture & Planning">Architecture & Planning</option>

                            <option value="Arts and Crafts">Arts and Crafts</option>

                            <option value="Automotive">Automotive</option>

                            <option value="Aviation & Aerospace">Aviation & Aerospace</option>

                            <option value="Banking">Banking</option>

                            <option value="Biotechnology">Biotechnology</option>

                            <option value="Broadcast Media">Broadcast Media</option>

                            <option value="Building Materials">Building Materials</option>

                            <option value="Business Supplies and Equipment">Business Supplies and Equipment</option>

                            <option value="Capital Markets">Capital Markets</option>

                            <option value="Chemicals">Chemicals</option>

                            <option value="Civic & Social Organization">Civic & Social Organization</option>

                            <option value="Civil Engineering">Civil Engineering</option>

                            <option value="Commercial Real Estate">Commercial Real Estate</option>

                            <option value="Computer & Network Security">Computer & Network Security</option>

                            <option value="Computer Games">Computer Games</option>

                            <option value="Computer Hardware">Computer Hardware</option>

                            <option value="Computer Networking">Computer Networking</option>

                            <option value="Computer Software">Computer Software</option>

                            <option value="Construction">Construction</option>

                            <option value="Consumer Electronics">Consumer Electronics</option>

                            <option value="Consumer Goods">Consumer Goods</option>

                            <option value="Consumer Services">Consumer Services</option>

                            <option value="Cosmetics">Cosmetics</option>

                            <option value="Dairy">Dairy</option>

                            <option value="Defense & Space">Defense & Space</option>

                            <option value="Design">Design</option>

                            <option value="Education Management">Education Management</option>

                            <option value="E-Learning">E-Learning</option>

                            <option value="Electrical/Electronic Manufacturing">Electrical/Electronic Manufacturing</option>

                            <option value="Entertainment">Entertainment</option>

                            <option value="Environmental Services">Environmental Services</option>

                            <option value="Events Services">Events Services</option>

                            <option value="Executive Office">Executive Office</option>

                            <option value="Facilities Services">Facilities Services</option>

                            <option value="Farming">Farming</option>

                            <option value="Financial Services">Financial Services</option>

                            <option value="Fine Art">Fine Art</option>

                            <option value="Fishery">Fishery</option>

                            <option value="Food & Beverages">Food & Beverages</option>

                            <option value="Food Production">Food Production</option>

                            <option value="Fund-Raising">Fund-Raising</option>

                            <option value="Furniture">Furniture</option>

                            <option value="Gambling & Casinos">Gambling & Casinos</option>

                            <option value="Glass, Ceramics & Concrete">Glass, Ceramics & Concrete</option>

                            <option value="Government Administration">Government Administration</option>

                            <option value="Government Relations">Government Relations</option>

                            <option value="Graphic Design">Graphic Design</option>

                            <option value="Health, Wellness and Fitness">Health, Wellness and Fitness</option>

                            <option value="Higher Education">Higher Education</option>

                            <option value="Hospital & Health Care">Hospital & Health Care</option>

                            <option value="Hospitality">Hospitality</option>

                            <option value="Human Resources">Human Resources</option>

                            <option value="Import and Export">Import and Export</option>

                            <option value="Individual & Family Services">Individual & Family Services</option>

                            <option value="Industrial Automation">Industrial Automation</option>

                            <option value="Information Services">Information Services</option>

                            <option value="Information Technology and Services">Information Technology and Services</option>

                            <option value="Insurance">Insurance</option>

                            <option value="International Affairs">International Affairs</option>

                            <option value="International Trade and Development">International Trade and Development</option>

                            <option value="Internet">Internet</option>

                            <option value="Investment Banking">Investment Banking</option>

                            <option value="Investment Management">Investment Management</option>

                            <option value="Judiciary">Judiciary</option>

                            <option value="Law Enforcement">Law Enforcement</option>

                            <option value="Law Practice">Law Practice</option>

                            <option value="Legal Services">Legal Services</option>

                            <option value="Legislative Office">Legislative Office</option>

                            <option value="Leisure, Travel & Tourism">Leisure, Travel & Tourism</option>

                            <option value="Libraries">Libraries</option>

                            <option value="Logistics and Supply Chain">Logistics and Supply Chain</option>

                            <option value="Luxury Goods & Jewelry">Luxury Goods & Jewelry</option>

                            <option value="Machinery">Machinery</option>

                            <option value="Management Consulting">Management Consulting</option>

                            <option value="Maritime">Maritime</option>

                            <option value="Market Research">Market Research</option>

                            <option value="Marketing and Advertising">Marketing and Advertising</option>

                            <option value="Mechanical or Industrial Engineering">Mechanical or Industrial Engineering</option>

                            <option value="Media Production">Media Production</option>

                            <option value="Medical Devices">Medical Devices</option>

                            <option value="Medical Practice">Medical Practice</option>

                            <option value="Mental Health Care">Mental Health Care</option>

                            <option value="Military">Military</option>

                            <option value="Mining & Metals">Mining & Metals</option>

                            <option value="Motion Pictures and Film">Motion Pictures and Film</option>

                            <option value="Museums and Institutions">Museums and Institutions</option>

                            <option value="Music">Music</option>

                            <option value="Nanotechnology">Nanotechnology</option>

                            <option value="Newspapers">Newspapers</option>

                            <option value="Non-Profit Organization Management">Non-Profit Organization Management</option>

                            <option value="Oil & Energy">Oil & Energy</option>

                            <option value="Online Media">Online Media</option>

                            <option value="Outsourcing/Offshoring">Outsourcing/Offshoring</option>

                            <option value="Package/Freight Delivery">Package/Freight Delivery</option>

                            <option value="Packaging and Containers">Packaging and Containers</option>

                            <option value="Paper & Forest Products">Paper & Forest Products</option>

                            <option value="Performing Arts">Performing Arts</option>

                            <option value="Pharmaceuticals">Pharmaceuticals</option>

                            <option value="Philanthropy">Philanthropy</option>

                            <option value="Photography">Photography</option>

                            <option value="Plastics">Plastics</option>

                            <option value="Political Organization">Political Organization</option>

                            <option value="Primary/Secondary Education">Primary/Secondary Education</option>

                            <option value="Printing">Printing</option>

                            <option value="Professional Training & Coaching">Professional Training & Coaching</option>

                            <option value="Program Development">Program Development</option>

                            <option value="Public Policy">Public Policy</option>

                            <option value="Public Relations and Communications">Public Relations and Communications</option>

                            <option value="Public Safety">Public Safety</option>

                            <option value="Publishing">Publishing</option>

                            <option value="Railroad Manufacture">Railroad Manufacture</option>

                            <option value="Ranching">Ranching</option>

                            <option value="Real Estate">Real Estate</option>

                            <option value="Recreational Facilities and Services">Recreational Facilities and Services</option>

                            <option value="Religious Institutions">Religious Institutions</option>

                            <option value="Renewables & Environment">Renewables & Environment</option>

                            <option value="Research">Research</option>

                            <option value="Restaurants">Restaurants</option>

                            <option value="Retail">Retail</option>

                            <option value="Security and Investigation">Security and Investigations</option>

                            <option value="Semiconductors">Semiconductors</option>

                            <option value="Shipbuilding">Shipbuilding</option>

                            <option value="Sporting Goods">Sporting Goods</option>

                            <option value="Sports">Sports</option>

                            <option value="Staffing and Recruiting">Staffing and Recruiting</option>

                            <option value="Supermarkets">Supermarkets</option>

                            <option value="Telecommunications">Telecommunications</option>

                            <option value="Textiles">Textiles</option>

                            <option value="Think Tanks">Think Tanks</option>

                            <option value="Tobacco">Tobacco</option>

                            <option value="Translation and Localization">Translation and Localization</option>

                            <option value="Transportation/Trucking/Railroad">Transportation/Trucking/Railroad</option>

                            <option value="Utilities">Utilities</option>

                            <option value="Venture Capital & Private Equity">Venture Capital & Private Equity</option>

                            <option value="Veterinary">Veterinary</option>

                            <option value="Warehousing">Warehousing</option>

                            <option value="Wholesale">Wholesale</option>

                            <option value="Wine and Spirits">Wine and Spirits</option>

                            <option value="Wireless">Wireless</option>

                            <option value="Writing and Editing">Writing and Editing</option>


                        </select>
                    </div>

                    <div class="form-group"> <!-- Description -->
                        <label for="bdescription" class="control-label">Description: </label>
                        <textarea class = "form-control" name = "bdescription"></textarea>
                    </div>

                    <div class = "form-group">
                        <label for = "bturnover" class = "control-label">Turnover: </label>
                        <input type = "text" name = "bturnover" class = "form-control">
                    </div>

                </div>

                <input type = "submit" class ="btn btn-primary" value = "Submit">
            </form>



            <!-- </form> -->


        </div>
    </div>
</div>



<script>
    var radios =  $(".current:checked").val();
    $('.job_form').show();
    $('.business_form').hide();
    $('.studies_form').hide();
    $('.current').on('change',function(){
        radios =  $(this).val();
        if(radios == 'job'){
            $('#company').prop('required',true);
            $('.job_form').show();
            $('.business_form').hide();
            $('.studies_form').hide();
        }
        if(radios == 'business'){
            $('.job_form').hide();
            $('.business_form').show();
            $('.studies_form').hide();
        }
        if(radios == 'studies'){
            $('.job_form').hide();
            $('.business_form').hide();
            $('.studies_form').show();
        }
    });
    $( function() {
        $( "#dob" ).datepicker({ dateFormat: 'yy-mm-dd', changeMonth: true ,changeYear: true });
        $( "#datepicker1" ).datepicker({ dateFormat: 'yy', changeYear: true });
        $( "#datepicker2" ).datepicker({ dateFormat: 'yy', changeYear: true });


    } );
</script>




</body>
</html>
