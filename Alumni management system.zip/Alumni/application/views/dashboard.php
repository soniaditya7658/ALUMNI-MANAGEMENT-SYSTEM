<?php foreach($events as $event): ?>
<div class="col-md-offset-2 col-md-8 blogShort">
    <h1><?php echo $event->e_name; ?></h1>
    <img src="<?php echo base_url(); ?>uploads/<?php echo $event->photo; ?>" class="img-responsive thumb margin10 img-thumbnail">
<br>
    <article><p>
            <?php echo $event->description; ?>
        <br><br>
            <?php echo 'Posted by ' . $event->first_name . ' at ' . $event->date_time; ?>
        </p></article>

</div>

<div class="col-md-12 gap10"></div>
<?php endforeach; ?>
</div>
</div>