<!--<div class="row">
    <div class="col-sm-6">
        <a href="#">Twitter</a> <small class="text-muted">|</small> <a href="#">Facebook</a> <small class="text-muted">|</small> <a href="#">Google+</a>
    </div>
</div>

<div class="row" id="footer">
    <div class="col-sm-6">

    </div>
    <div class="col-sm-6">
        <p>
            <a href="#" class="pull-right">copyright 2017</a>
        </p>
    </div>
</div>-->


</div><!-- /col-9 -->
</div><!-- /padding -->
</div>
<!-- /main -->

</div>
</div>
</div>


<!--post modal-->
<div id="postModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">׼/button>
                    Update Status
            </div>
            <div class="modal-body">
                <form class="form center-block">
                    <div class="form-group">
                        <textarea class="form-control input-lg" autofocus="" placeholder="What do you want to share?"></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <div>
                    <button class="btn btn-primary btn-sm" data-dismiss="modal" aria-hidden="true">Post</button>
                    <ul class="pull-left list-inline"><li><a href=""><i class="glyphicon glyphicon-upload"></i></a></li><li><a href=""><i class="glyphicon glyphicon-camera"></i></a></li><li><a href=""><i class="glyphicon glyphicon-map-marker"></i></a></li></ul>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript" src="http://code.jquery.com/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('[data-toggle=offcanvas]').click(function() {
            $(this).toggleClass('visible-xs text-center');
            $(this).find('i').toggleClass('glyphicon-chevron-right glyphicon-chevron-left');
            $('.row-offcanvas').toggleClass('active');
            $('#lg-menu').toggleClass('hidden-xs').toggleClass('visible-xs');
            $('#xs-menu').toggleClass('visible-xs').toggleClass('hidden-xs');
            $('#btnShow').toggle();
        });
    });
</script>

<script>
    $('.attending').click(function(){

        var id = $(this).attr('data-id');
        var status = 1;
        $.post("<?php echo base_url() . 'index.php/Event/status' ?>",{id: id,status:status}, function(data, status){
            $('.' + id + 'm').css('color','black');
            $('.' +id + 'a').css('color','green');
            $('.' +id + 'n').css('color','black');
        });
    });

    $('.maybe').click(function(){
        var id = $(this).attr('data-id');

        var status = 2;
        $.post("<?php echo base_url() . 'index.php/Event/status' ?>",{id: id, status:status}, function(data, status){
            $('.' + id + 'm').css('color','green');
            $('.' +id + 'a').css('color','black');
            $('.' +id + 'n').css('color','black');

        });
    });

    $('.not_attending').click(function(){
        var id = $(this).attr('data-id');
        $(this).css('color','green');
        $('.' +id + 'm').css('color','black');
        $('.' +id + 'n').css('color','black');
        var status = 3;
        $.post("<?php echo base_url() . 'index.php/Event/status' ?>",{id: id,status:status}, function(data, status){
            $('.' + id + 'm').css('color','black');
            $('.' +id + 'a').css('color','black');
            $('.' +id + 'n').css('color','green');
        });
    });

    $('.reply').click(function(){
        var id = $(this).attr('data-id');
        var cla = "#rtext_" + id;
        var text = $(cla).val();
        $.post("<?php echo base_url() . 'index.php/Request/reply' ?>",{id: id,text:text}, function(data, status){
            alert(data);
        });
    });
</script>

<script>
    $(document).ready(function(){
        $('#myModalx').modal('show');

    });
    function readURL(input) {

        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }

    $("#photo").change(function(){
        readURL(this);
    });

    $("form#data").submit(function() {
        var formData = new FormData($(this)[0]);

        $.ajax({
            url: "<?php echo base_url() . 'index.php/Student/update_basic' ?>",
            type: 'POST',
            data: formData,
            async: false,
            success: function (data) {
                alert(data)
            },
            cache: false,
            contentType: false,
            processData: false
        });

        return false;
    });

    $("form#addexperience").submit(function() {
        var formData = new FormData($(this)[0]);

        $.ajax({
            url: "<?php echo base_url() . 'index.php/Student/add_exp' ?>",
            type: 'POST',
            data: formData,
            async: false,
            success: function (data) {
                if(data == 'Added Successfully'){

                }
            },
            cache: false,
            contentType: false,
            processData: false
        });

        return false;
    });
</script>
<script type="text/javascript">

    $(document).ready(function(){

        $('#profile_pic').change(function() {
            var file_data = $(this).prop('files')[0];
			
            var form_data = new FormData();
            form_data.append('file', file_data);

            var pre = "<?php echo base_url() . 'uploads/'?>";
            $.ajax({
                url: "<?php echo base_url() . 'index.php/Student/image_upload' ?>", // point to server-side controller method
                dataType: 'text', // what to expect back from the server
                cache: false,
                contentType: false,
                processData: false,
                data: form_data,
                type: 'post',
                success: function (response) {
                    var img = pre + response;

                    $('#avatar').attr('src', img);
                    alert('Profile Image Updated Successfully!');
                },
                error: function (response) {
                    alert(response); // display error response from the server
                }
            });

        });
    });

</script>
</body></html>