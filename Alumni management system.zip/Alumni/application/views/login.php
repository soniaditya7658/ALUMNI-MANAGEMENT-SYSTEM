<!DOCTYPE html>
<html >
<head>
    <meta charset="UTF-8">
    <title>Thakur College Of Science and Commerce</title>
    <link href='https://fonts.googleapis.com/css?family=Titillium+Web:400,300,600' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">


    <link href="<?php echo base_url(); ?>public_html/css/login.css" rel="stylesheet">


</head>

<body>
<div class="form">

    <h1>Thakur College of Science and Commerce Alumni Portal</h1>

    <ul class="tab-group">
        <li class="tab <?php if(!isset($_GET['status'])): echo 'active'; endif; ?>"><a href="#signup">Sign Up</a></li>
        <li class="tab <?php if(isset($_GET['status'])): echo 'active'; endif; ?>"><a href="#login">Log In</a></li>
    </ul>
    <?php if(isset($_GET['status'])): ?>
        <div class="alert alert-danger" style = "color:red;" role="alert"><center>Email Address or Password do not match</center></div>
    <?php endif; ?>
    <div class="tab-content">
        <div id="signup"  <?php if(isset($_GET['status'])): echo "style = 'display:none;'"; endif; ?>>
            <h1>Sign Up for Free</h1>

            <form action="<?php echo base_url() . 'index.php/User/student_register' ?>" method="post">

                <div class="top-row">
                    <div class="field-wrap">
                        <label>
                            First Name<span class="req">*</span>
                        </label>
                        <input type="text" name = "first_name" required autocomplete="off" />
                    </div>

                    <div class="field-wrap">
                        <label>
                            Last Name<span class="req">*</span>
                        </label>
                        <input type="text" name = "last_name" required autocomplete="off"/>
                    </div>
                </div>

                <div class="field-wrap">
                    <label>
                        Email Address<span class="req">*</span>
                    </label>
                    <input type="email" name = "email" required autocomplete="off"/>
                </div>

                <div class="field-wrap">
                    <label>
                        Set A Password<span class="req">*</span>
                    </label>
                    <input type="password" name = "password" required autocomplete="off"/>
                </div>

                <button type="submit" class="button button-block"/>Get Started</button>

            </form>

        </div>

        <div id="login" <?php if(isset($_GET['status'])): echo "style = 'display:block;'"; endif; ?>>
            <h1>Welcome Back!</h1>

            <form action="<?php echo base_url() . 'index.php/User/student_login' ?>" method="post">

                <div class="field-wrap">
                    <label>
                        Email Address<span class="req">*</span>
                    </label>
                    <input type="email" name = "email" required autocomplete="off"/>
                </div>

                <div class="field-wrap">
                    <label>
                        Password<span class="req">*</span>
                    </label>
                    <input type="password" name = "password" required autocomplete="off"/>
                </div>

                <p class="forgot"><a href="<?php echo base_url().'index.php/Auth/forgot_password'?>">Forgot Password?</a></p>

                <button class="button button-block"/>Log In</button>

            </form>

        </div>

    </div><!-- tab-content -->

</div> <!-- /form -->
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

<script src="<?php echo base_url(); ?>public_html/js/login.js"></script>

</body>
</html>
