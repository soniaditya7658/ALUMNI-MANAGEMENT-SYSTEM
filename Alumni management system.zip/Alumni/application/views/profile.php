<style>
    /***
Bootstrap Line Tabs by @keenthemes
A component of Metronic Theme - #1 Selling Bootstrap 3 Admin Theme in Themeforest: http://j.mp/metronictheme
Licensed under MIT
***/

    /* Tabs panel */
    .tabbable-panel {
        border:1px solid #eee;
        padding: 10px;
    }

    /* Default mode */
    .tabbable-line > .nav-tabs {
        border: none;
        margin: 0px;
    }
    .tabbable-line > .nav-tabs > li {
        margin-right: 2px;
    }
    .tabbable-line > .nav-tabs > li > a {
        border: 0;
        margin-right: 0;
        color: #737373;
    }
    .tabbable-line > .nav-tabs > li > a > i {
        color: #a6a6a6;
    }
    .tabbable-line > .nav-tabs > li.open, .tabbable-line > .nav-tabs > li:hover {
        border-bottom: 4px solid #fbcdcf;
    }
    .tabbable-line > .nav-tabs > li.open > a, .tabbable-line > .nav-tabs > li:hover > a {
        border: 0;
        background: none !important;
        color: #333333;
    }
    .tabbable-line > .nav-tabs > li.open > a > i, .tabbable-line > .nav-tabs > li:hover > a > i {
        color: #a6a6a6;
    }
    .tabbable-line > .nav-tabs > li.open .dropdown-menu, .tabbable-line > .nav-tabs > li:hover .dropdown-menu {
        margin-top: 0px;
    }
    .tabbable-line > .nav-tabs > li.active {
        border-bottom: 4px solid #f3565d;
        position: relative;
    }
    .tabbable-line > .nav-tabs > li.active > a {
        border: 0;
        color: #333333;
    }
    .tabbable-line > .nav-tabs > li.active > a > i {
        color: #404040;
    }
    .tabbable-line > .tab-content {
        margin-top: -3px;
        background-color: #fff;
        border: 0;
        border-top: 1px solid #eee;
        padding: 15px 0;
    }
    .portlet .tabbable-line > .tab-content {
        padding-bottom: 0;
    }

    /* Below tabs mode */

    .tabbable-line.tabs-below > .nav-tabs > li {
        border-top: 4px solid transparent;
    }
    .tabbable-line.tabs-below > .nav-tabs > li > a {
        margin-top: 0;
    }
    .tabbable-line.tabs-below > .nav-tabs > li:hover {
        border-bottom: 0;
        border-top: 4px solid #fbcdcf;
    }
    .tabbable-line.tabs-below > .nav-tabs > li.active {
        margin-bottom: -2px;
        border-bottom: 0;
        border-top: 4px solid #f3565d;
    }
    .tabbable-line.tabs-below > .tab-content {
        margin-top: -10px;
        border-top: 0;
        border-bottom: 1px solid #eee;
        padding-bottom: 15px;
    }
</style>
<div class="container">
    <h1 style = "width:100%; text-align:center;">Profile</h1>
    <hr>
    <div class="row">
        <!-- left column -->
        <div class="col-md-3">
            <div class="text-center">

                <?php if(!isset($basic_info->image)): ?>
                <img src="http://placehold.it/100" width = "100px" height = "100px" id = "avatar" class="avatar img-circle" alt="avatar">
                <?php else: ?>
                    <img src="<?php echo base_url() . 'uploads/' . $basic_info->image ?>" width = "100px" height = "100px" id = "avatar" class="avatar img-circle" alt="avatar">
                <?php endif; ?>
                <h6>Upload a different photo...</h6>

                <input type="file" id = "profile_pic"  class="form-control">
            </div>
        </div>

        <!-- edit form column -->
        <div class="col-md-9 personal-info">

            <div class="tabbable-panel">
                <div class="tabbable-line">
                    <ul class="nav nav-tabs ">
                        <li class="active">
                            <a href="#personal" data-toggle="tab">
                                Personal </a>
                        </li>
                        <li>
                            <a href="#jobs" data-toggle="tab">
                                Job</a>
                        </li>
                        <li>
                            <a href="#educational" data-toggle="tab">
                                Educational</a>
                        </li>

                        <li>
                            <a href="#business" data-toggle="tab">
                                Business</a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane active" id="personal">
                            <div class="alert alert-info alert-dismissable">
                                <a class="panel-close close" data-dismiss="alert">×</a>
                                <i class="fa fa-coffee"></i>
                                <?php if(isset($_GET['status'])): ?>
                                Updated Successfully!
                                <?php else: ?>
                                All the fields are <strong>Compulsory</strong>
                                <?php endif; ?>
                            </div>

                            <form class="form-horizontal" role="form" action = "<?php echo base_url() . 'index.php/Student/update_basic' ?>" method = "post" enctype="multipart/form-data">
                                <div class="form-group">
                                    <label class="col-lg-3 control-label">First name:<span style = "color:red;">*</span></label>
                                    <div class="col-lg-8">
                                        <input class="form-control" required name = "first_name" type="text" placeholder="Jane" value = "<?php echo (isset($basic_info->first_name)) ? $basic_info->first_name : ''; ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-lg-3 control-label">Middle name:<span style = "color:red;">*</span></label>
                                    <div class="col-lg-8">
                                        <input class="form-control" required name = "middle_name" type="text" placeholder="Doe" value = "<?php echo (isset($basic_info->middle_name)) ? $basic_info->middle_name : ''; ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-lg-3 control-label">Last name:<span style = "color:red;">*</span></label>
                                    <div class="col-lg-8">
                                        <input class="form-control" required name = "last_name" type="text" placeholder="Bishop" value = "<?php echo (isset($basic_info->last_name)) ? $basic_info->last_name : ''; ?>">
                                    </div>
                                </div>

                                <div class = "form-group">
                                    <label class="col-lg-3 control-label">Gender:<span style = "color:red;">*</span></label>
                                    <div class="col-lg-2">
                                        <input <?php if(isset($basic_info->gender) && $basic_info->gender == '1'): echo 'checked'; endif; ?> type = "radio" name = "gender" value = "1" required> Male

                                    </div>
                                    <div class="col-lg-2">
                                        <input <?php if(isset($basic_info->gender) && $basic_info->gender == '2'): echo 'checked'; endif; ?> type = "radio" name = "gender" value = "2" required> Female

                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-lg-3 control-label">Mothers Name:<span style = "color:red;">*</span></label>
                                    <div class="col-lg-8">
                                        <input name = "mothers_name" class="form-control" type="text" value = "<?php echo (isset($basic_info->mothers_name)) ? $basic_info->mothers_name : ''; ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-lg-3 control-label">Fathers Name:<span style = "color:red;">*</span></label>
                                    <div class="col-lg-8">
                                        <input name = "fathers_name" class="form-control" type="text" value = "<?php echo (isset($basic_info->fathers_name)) ? $basic_info->fathers_name : ''; ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-lg-3 control-label">Date of Birth:<span style = "color:red;">*</span> </label>
                                    <div class="col-lg-8">
                                        <input name = "dob" class="form-control" type="date" value = "<?php echo (isset($basic_info->date_of_birth)) ? $basic_info->date_of_birth : ''; ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-lg-3 control-label">Email: <span style = "color:red;">*</span></label>
                                    <div class="col-lg-8">
                                        <input name = "email" class="form-control" type="email" placeholder="janesemail@gmail.com" value ="<?php echo (isset($basic_info->email)) ? $basic_info->email : ''; ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-lg-3 control-label">Address: <span style = "color:red;">*</span></label>
                                    <div class="col-lg-8">
                                        <textarea class = "form-control" required name = "address" ><?php echo (isset($basic_info->address)) ? $basic_info->address : ''; ?></textarea>

                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-lg-3 control-label">Phone: <span style = "color:red;">*</span></label>
                                    <div class="col-lg-8">
                                        <input type="text" required class="form-control" name="phone" value = "<?php echo (isset($basic_info->phone_no)) ? $basic_info->phone_no : ''; ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-lg-3 control-label">Passed Year: <span style = "color:red;">*</span> </label>
                                    <div class="col-lg-8">
                                        <input type="text" max = "4" min = "4" placeholder="2016" required class="form-control" name="passed_year" value = "<?php echo (isset($basic_info->passed_year)) ? $basic_info->passed_year : ''; ?>">

                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-lg-3 control-label">UID: <span style = "color:red;">*</span> </label>
                                    <div class="col-lg-8">
                                        <input type="text" placeholder="1520456" required class="form-control" name="uid" value = "<?php echo (isset($basic_info->uid)) ? $basic_info->uid : ''; ?>">

                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-lg-3 control-label">Course <span style = "color:red;">*</span></label>
                                    <div class="col-lg-8">
                                        <div class="ui-select">
                                            <select name = "course" required class="form-control">
											<option value="">Select Option</option>
                                                <option <?php if(isset($basic_info->course) && $basic_info->course == 'Botany'): echo 'selected'; endif; ?> value = "Botany">Botany</option>
                                                <option <?php if(isset($basic_info->course) && $basic_info->course == 'Chemistry'): echo 'selected'; endif; ?> value = "Chemistry">Chemistry</option>
                                                <option <?php if(isset($basic_info->course) && $basic_info->course == 'Physics'): echo 'selected'; endif; ?> value = "Physics">Physics</option>
                                                <option <?php if(isset($basic_info->course) && $basic_info->course == 'Bio-Tech'): echo 'selected'; endif; ?> value = "Bio-Tech">Bio-Tech</option>
                                                <option <?php if(isset($basic_info->course) && $basic_info->course == 'Zoology'): echo 'selected'; endif; ?> value = "Zoology">Zoology</option>
                                                <option <?php if(isset($basic_info->course) && $basic_info->course == 'BSC Computer Science'): echo 'selected'; endif; ?> value = "BSC Computer Science">BSC Computer Science</option>
                                                <option <?php if(isset($basic_info->course) && $basic_info->course == 'BSC IT'): echo 'selected'; endif; ?> value = "BSC IT">BSC IT</option>
                                                <option <?php if(isset($basic_info->course) && $basic_info->course == 'Science Maths'): echo 'selected'; endif; ?> value = "Science Maths">Science Maths</option>
                                                <option <?php if(isset($basic_info->course) && $basic_info->course == 'BSC Aviation'): echo 'selected'; endif; ?> value = "BSC Aviation">BSC Aviation</option>
                                                <option <?php if(isset($basic_info->course) && $basic_info->course == 'Human Science'): echo 'selected'; endif; ?> value = "Human Science">Human Science</option>
                                                <option <?php if(isset($basic_info->course) && $basic_info->course == 'Economics'): echo 'selected'; endif; ?> value = "Economics">Economics</option>
                                                <option <?php if(isset($basic_info->course) && $basic_info->course == 'Accounts'): echo 'selected'; endif; ?> value = "Accounts">Accounts</option>
                                                <option <?php if(isset($basic_info->course) && $basic_info->course == 'Commerce Maths'): echo 'selected'; endif; ?> value = "Commerce Maths">Commerce Maths</option>
                                                <option <?php if(isset($basic_info->course) && $basic_info->course == 'EVS'): echo 'selected'; endif; ?> value = "EVS">EVS</option>
                                                <option <?php if(isset($basic_info->course) && $basic_info->course == 'FC'): echo 'selected'; endif; ?> value = "FC">FC</option>
                                                <option <?php if(isset($basic_info->course) && $basic_info->course == 'Business Communication'): echo 'selected'; endif; ?> value = "Business Communication">Business Communication</option>
                                                <option <?php if(isset($basic_info->course) && $basic_info->course == 'Business Law'): echo 'selected'; endif; ?> value = "Business Law">Business Law</option>
                                                <option <?php if(isset($basic_info->course) && $basic_info->course == 'Commerce'): echo 'selected'; endif; ?> value = "Commerce">Commerce</option>
                                                <option <?php if(isset($basic_info->course) && $basic_info->course == 'Financial Market'): echo 'selected'; endif; ?> value = "Financial Market">Financial Market</option>
                                                <option <?php if(isset($basic_info->course) && $basic_info->course == 'BMS'): echo 'selected'; endif; ?> value = "BMS">BMS</option>
                                                <option <?php if(isset($basic_info->course) && $basic_info->course == 'Banking and Insurance'): echo 'selected'; endif; ?> value = "Banking and Insurance">Banking and Insurance</option>
                                                <option <?php if(isset($basic_info->course) && $basic_info->course == 'BIM'): echo 'selected'; endif; ?> value = "BIM">BIM</option>
                                                <option <?php if(isset($basic_info->course) && $basic_info->course == 'Accounting Finance'): echo 'selected'; endif; ?> value = "Accounting Finance">Accounting Finance</option>
                                                <option <?php if(isset($basic_info->course) && $basic_info->course == 'BMM'): echo 'selected'; endif; ?> value = "BMM">BMM</option>
                                                <option <?php if(isset($basic_info->course) && $basic_info->course == 'Human Science'): echo 'selected'; endif; ?> value = "Human Science">Human Science</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label">Average Grade: <span style = "color:red;">*</span></label>
                                    <div class="col-md-8">
                                        <input type="text" placeholder="A" required class="form-control" name="average_grade" value = "<?php echo (isset($basic_info->average_percentage)) ? $basic_info->average_percentage : ''; ?>">

                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-md-3 control-label"></label>
                                    <div class="col-md-8">
                                        <input type="submit" class="btn btn-primary" value="Save Changes">

                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="tab-pane" id="jobs">
                            <form class="form-horizontal" role="form" method = "post" action = "<?php echo base_url() . 'index.php/Student/add_exp' ?>">
                                <div class="form-group">
                                    <label class="col-lg-3 control-label">Company Name: </label>
                                    <div class="col-lg-8">
                                        <input type = "text" name = "company" class = "form-control" <?php if(isset($jobs) and count($jobs) > 0): ?> value = "<?php echo $jobs[0]->company_name ?>" <?php endif; ?>>
                                    </div>
                                </div>


                                <div class="form-group">
                                    <label class="col-lg-3 control-label">Position</label>
                                    <div class="col-lg-8">
                                        <input type = "text" name = "position" class = "form-control" <?php if(isset($jobs) and count($jobs) > 0): ?> value = "<?php echo $jobs[0]->position; ?>" <?php endif; ?>>
                                    </div>
                                </div>

                                <div class = "form-group">
                                    <label class="col-lg-3 control-label">Start Year:</label>
                                    <div class = "col-lg-8">
                                        <input type = "text" name = "start_year" class = "form-control" <?php if(isset($jobs) and count($jobs) > 0): ?> value = "<?php echo $jobs[0]->start_year; ?>" <?php endif; ?>>

                                    </div>
                                </div>


                                <div class="form-group">
                                    <label class="col-lg-3 control-label">Industry</label>
                                    <div class="col-lg-8">
                                        <div class="ui-select">
                                            <select name="industry" class="form-control">
											<option value="">Select Option</option>
                                                <option value="Accounting">Accounting</option>

                                                <option value="Airlines/Aviation">Airlines/Aviation</option>

                                                <option  value="Alternative Dispute Resolution">Alternative Dispute Resolution</option>

                                                <option value="Alternative Medicine">Alternative Medicine</option>

                                                <option value="Animation">Animation</option>

                                                <option value="Apparel & Fashion">Apparel & Fashion</option>

                                                <option value="Architecture & Planning">Architecture & Planning</option>

                                                <option value="Arts and Crafts">Arts and Crafts</option>

                                                <option value="Automotive">Automotive</option>

                                                <option value="Aviation & Aerospace">Aviation & Aerospace</option>

                                                <option value="Banking">Banking</option>

                                                <option value="Biotechnology">Biotechnology</option>

                                                <option value="Broadcast Media">Broadcast Media</option>

                                                <option value="Building Materials">Building Materials</option>

                                                <option  value="Business Supplies and Equipment">Business Supplies and Equipment</option>

                                                <option  value="Capital Markets">Capital Markets</option>

                                                <option  value="Chemicals">Chemicals</option>

                                                <option value="Civic & Social Organization">Civic & Social Organization</option>

                                                <option  value="Civil Engineering">Civil Engineering</option>

                                                <option value="Commercial Real Estate">Commercial Real Estate</option>

                                                <option value="Computer & Network Security">Computer & Network Security</option>

                                                <option value="Computer Games">Computer Games</option>

                                                <option value="Computer Hardware">Computer Hardware</option>

                                                <option value="Computer Networking">Computer Networking</option>

                                                <option value="Computer Software">Computer Software</option>

                                                <option value="Construction">Construction</option>

                                                <option  value="Consumer Electronics">Consumer Electronics</option>

                                                <option value="Consumer Goods">Consumer Goods</option>

                                                <option value="Consumer Services">Consumer Services</option>

                                                <option value="Cosmetics">Cosmetics</option>

                                                <option value="Dairy">Dairy</option>

                                                <option value="Defense & Space">Defense & Space</option>

                                                <option value="Design">Design</option>

                                                <option  value="Education Management">Education Management</option>

                                                <option  value="E-Learning">E-Learning</option>

                                                <option  value="Electrical/Electronic Manufacturing">Electrical/Electronic Manufacturing</option>

                                                <option value="Entertainment">Entertainment</option>

                                                <option  value="Environmental Services">Environmental Services</option>

                                                <option value="Events Services">Events Services</option>

                                                <option  value="Executive Office">Executive Office</option>

                                                <option value="Facilities Services">Facilities Services</option>

                                                <option  value="Farming">Farming</option>

                                                <option  value="Financial Services">Financial Services</option>

                                                <option  value="Fine Art">Fine Art</option>

                                                <option value="Fishery">Fishery</option>

                                                <option value="Food & Beverages">Food & Beverages</option>

                                                <option value="Food Production">Food Production</option>

                                                <option value="Fund-Raising">Fund-Raising</option>

                                                <option value="Furniture">Furniture</option>

                                                <option value="Gambling & Casinos">Gambling & Casinos</option>

                                                <option value="Glass, Ceramics & Concrete">Glass, Ceramics & Concrete</option>

                                                <option value="Government Administration">Government Administration</option>

                                                <option value="Government Relations">Government Relations</option>

                                                <option value="Graphic Design">Graphic Design</option>

                                                <option value="Health, Wellness and Fitness">Health, Wellness and Fitness</option>

                                                <option value="Higher Education">Higher Education</option>

                                                <option value="Hospital & Health Care">Hospital & Health Care</option>

                                                <option value="Hospitality">Hospitality</option>

                                                <option value="Human Resources">Human Resources</option>

                                                <option value="Import and Export">Import and Export</option>

                                                <option value="Individual & Family Services">Individual & Family Services</option>

                                                <option value="Industrial Automation">Industrial Automation</option>

                                                <option value="Information Services">Information Services</option>

                                                <option value="Information Technology and Services">Information Technology and Services</option>

                                                <option value="Insurance">Insurance</option>

                                                <option value="International Affairs">International Affairs</option>

                                                <option value="International Trade and Development">International Trade and Development</option>

                                                <option value="Internet">Internet</option>

                                                <option value="Investment Banking">Investment Banking</option>

                                                <option value="Investment Management">Investment Management</option>

                                                <option value="Judiciary">Judiciary</option>

                                                <option value="Law Enforcement">Law Enforcement</option>

                                                <option value="Law Practice">Law Practice</option>

                                                <option value="Legal Services">Legal Services</option>

                                                <option value="Legislative Office">Legislative Office</option>

                                                <option value="Leisure, Travel & Tourism">Leisure, Travel & Tourism</option>

                                                <option value="Libraries">Libraries</option>

                                                <option value="Logistics and Supply Chain">Logistics and Supply Chain</option>

                                                <option value="Luxury Goods & Jewelry">Luxury Goods & Jewelry</option>

                                                <option value="Machinery">Machinery</option>

                                                <option value="Management Consulting">Management Consulting</option>

                                                <option value="Maritime">Maritime</option>

                                                <option value="Market Research">Market Research</option>

                                                <option value="Marketing and Advertising">Marketing and Advertising</option>

                                                <option value="Mechanical or Industrial Engineering">Mechanical or Industrial Engineering</option>

                                                <option value="Media Production">Media Production</option>

                                                <option value="Medical Devices">Medical Devices</option>

                                                <option value="Medical Practice">Medical Practice</option>

                                                <option value="Mental Health Care">Mental Health Care</option>

                                                <option value="Military">Military</option>

                                                <option value="Mining & Metals">Mining & Metals</option>

                                                <option value="Motion Pictures and Film">Motion Pictures and Film</option>

                                                <option value="Museums and Institutions">Museums and Institutions</option>

                                                <option value="Music">Music</option>

                                                <option value="Nanotechnology">Nanotechnology</option>

                                                <option value="Newspapers">Newspapers</option>

                                                <option value="Non-Profit Organization Management">Non-Profit Organization Management</option>

                                                <option value="Oil & Energy">Oil & Energy</option>

                                                <option value="Online Media">Online Media</option>

                                                <option value="Outsourcing/Offshoring">Outsourcing/Offshoring</option>

                                                <option value="Package/Freight Delivery">Package/Freight Delivery</option>

                                                <option value="Packaging and Containers">Packaging and Containers</option>

                                                <option value="Paper & Forest Products">Paper & Forest Products</option>

                                                <option value="Performing Arts">Performing Arts</option>

                                                <option value="Pharmaceuticals">Pharmaceuticals</option>

                                                <option value="Philanthropy">Philanthropy</option>

                                                <option value="Photography">Photography</option>

                                                <option value="Plastics">Plastics</option>

                                                <option value="Political Organization">Political Organization</option>

                                                <option value="Primary/Secondary Education">Primary/Secondary Education</option>

                                                <option value="Printing">Printing</option>

                                                <option value="Professional Training & Coaching">Professional Training & Coaching</option>

                                                <option value="Program Development">Program Development</option>

                                                <option value="Public Policy">Public Policy</option>

                                                <option value="Public Relations and Communications">Public Relations and Communications</option>

                                                <option value="Public Safety">Public Safety</option>

                                                <option value="Publishing">Publishing</option>

                                                <option value="Railroad Manufacture">Railroad Manufacture</option>

                                                <option value="Ranching">Ranching</option>

                                                <option value="Real Estate">Real Estate</option>

                                                <option value="Recreational Facilities and Services">Recreational Facilities and Services</option>

                                                <option value="Religious Institutions">Religious Institutions</option>

                                                <option value="Renewables & Environment">Renewables & Environment</option>

                                                <option value="Research">Research</option>

                                                <option value="Restaurants">Restaurants</option>

                                                <option value="Retail">Retail</option>

                                                <option value="Security and Investigation">Security and Investigations</option>

                                                <option value="Semiconductors">Semiconductors</option>

                                                <option value="Shipbuilding">Shipbuilding</option>

                                                <option value="Sporting Goods">Sporting Goods</option>

                                                <option value="Sports">Sports</option>

                                                <option value="Staffing and Recruiting">Staffing and Recruiting</option>

                                                <option value="Supermarkets">Supermarkets</option>

                                                <option value="Telecommunications">Telecommunications</option>

                                                <option value="Textiles">Textiles</option>

                                                <option value="Think Tanks">Think Tanks</option>

                                                <option value="Tobacco">Tobacco</option>

                                                <option value="Translation and Localization">Translation and Localization</option>

                                                <option value="Transportation/Trucking/Railroad">Transportation/Trucking/Railroad</option>

                                                <option value="Utilities">Utilities</option>

                                                <option value="Venture Capital & Private Equity">Venture Capital & Private Equity</option>

                                                <option value="Veterinary">Veterinary</option>

                                                <option value="Warehousing">Warehousing</option>

                                                <option value="Wholesale">Wholesale</option>

                                                <option value="Wine and Spirits">Wine and Spirits</option>

                                                <option value="Wireless">Wireless</option>

                                                <option value="Writing and Editing">Writing and Editing</option>


                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-md-3 control-label"></label>
                                    <div class="col-md-8">
                                        <input type="submit" class="btn btn-primary" value="Save Changes">

                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="tab-pane" id="educational">
                            <form class="form-horizontal" role="form" method = "post" action = "<?php echo base_url() . 'index.php/Student/edit_edu' ?>">
                                <div class="form-group">
                                    <label class="col-lg-3 control-label">Institute Name: </label>
                                    <div class="col-lg-8">
                                        <input type = "text" name = "institute" class = "form-control"  <?php if(isset($academics)  and count($academics) > 0): ?>value = "<?php echo $academics[0]->college_name; ?>" <?php endif; ?>>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-lg-3 control-label">Field of Study: </label>
                                    <div class="col-lg-8">
                                        <input type = "text" name = "fos" class = "form-control"  <?php if(isset($academics)  and count($academics) > 0): ?>value = "<?php echo $academics[0]->field_of_study; ?>" <?php endif; ?>>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-lg-3 control-label">Degree</label>
                                    <div class="col-lg-8">
                                        <input type = "text" name = "degree" class = "form-control"  <?php if(isset($academics)  and count($academics) > 0): ?>value = "<?php echo $academics[0]->degree; ?>" <?php endif; ?>>
                                    </div>
                                </div>

                                <div class = "form-group">
                                    <label class="col-lg-3 control-label">Start Year:</label>
                                    <div class = "col-lg-8">
                                        <input type = "text"  name = "start_year" class = "form-control"  <?php if(isset($academics) and count($academics) > 0): ?>value = "<?php echo $academics[0]->start_year; ?>" <?php endif; ?>>

                                    </div>
                                </div>



                                <div class="form-group">
                                    <label class="col-md-3 control-label"></label>
                                    <div class="col-md-8">
                                        <input type="submit" class="btn btn-primary" value="Save Changes">

                                    </div>
                                </div>
                            </form>
                        </div>

                        <div class="tab-pane" id="business">
                            <form class="form-horizontal" role="form" method = "post" action = "<?php echo base_url() . 'index.php/Student/edit_bus'?>">
                                <div class="form-group">
                                    <label class="col-lg-3 control-label">Company Name: </label>
                                    <div class="col-lg-8">
                                        <input type = "text" name = "c_name" class = "form-control" <?php if(isset($business) and count($business) > 0): ?> value = "<?php echo $business[0]->company_name; ?>" <?php endif; ?>>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-lg-3 control-label">Industry:  </label>
                                    <div class="col-lg-8">
                                        <select name="industry" class="form-control">
										<option value="">Select Option</option>
                                            <option value="Accounting">Accounting</option>

                                            <option value="Airlines/Aviation">Airlines/Aviation</option>

                                            <option value="Alternative Dispute Resolution">Alternative Dispute Resolution</option>

                                            <option value="Alternative Medicine">Alternative Medicine</option>

                                            <option value="Animation">Animation</option>

                                            <option value="Apparel & Fashion">Apparel & Fashion</option>

                                            <option value="Architecture & Planning">Architecture & Planning</option>

                                            <option value="Arts and Crafts">Arts and Crafts</option>

                                            <option value="Automotive">Automotive</option>

                                            <option value="Aviation & Aerospace">Aviation & Aerospace</option>

                                            <option value="Banking">Banking</option>

                                            <option value="Biotechnology">Biotechnology</option>

                                            <option value="Broadcast Media">Broadcast Media</option>

                                            <option value="Building Materials">Building Materials</option>

                                            <option value="Business Supplies and Equipment">Business Supplies and Equipment</option>

                                            <option value="Capital Markets">Capital Markets</option>

                                            <option value="Chemicals">Chemicals</option>

                                            <option value="Civic & Social Organization">Civic & Social Organization</option>

                                            <option value="Civil Engineering">Civil Engineering</option>

                                            <option value="Commercial Real Estate">Commercial Real Estate</option>

                                            <option value="Computer & Network Security">Computer & Network Security</option>

                                            <option value="Computer Games">Computer Games</option>

                                            <option value="Computer Hardware">Computer Hardware</option>

                                            <option value="Computer Networking">Computer Networking</option>

                                            <option value="Computer Software">Computer Software</option>

                                            <option value="Construction">Construction</option>

                                            <option value="Consumer Electronics">Consumer Electronics</option>

                                            <option value="Consumer Goods">Consumer Goods</option>

                                            <option value="Consumer Services">Consumer Services</option>

                                            <option value="Cosmetics">Cosmetics</option>

                                            <option value="Dairy">Dairy</option>

                                            <option value="Defense & Space">Defense & Space</option>

                                            <option value="Design">Design</option>

                                            <option value="Education Management">Education Management</option>

                                            <option value="E-Learning">E-Learning</option>

                                            <option value="Electrical/Electronic Manufacturing">Electrical/Electronic Manufacturing</option>

                                            <option value="Entertainment">Entertainment</option>

                                            <option value="Environmental Services">Environmental Services</option>

                                            <option value="Events Services">Events Services</option>

                                            <option value="Executive Office">Executive Office</option>

                                            <option value="Facilities Services">Facilities Services</option>

                                            <option value="Farming">Farming</option>

                                            <option value="Financial Services">Financial Services</option>

                                            <option value="Fine Art">Fine Art</option>

                                            <option value="Fishery">Fishery</option>

                                            <option value="Food & Beverages">Food & Beverages</option>

                                            <option value="Food Production">Food Production</option>

                                            <option value="Fund-Raising">Fund-Raising</option>

                                            <option value="Furniture">Furniture</option>

                                            <option value="Gambling & Casinos">Gambling & Casinos</option>

                                            <option value="Glass, Ceramics & Concrete">Glass, Ceramics & Concrete</option>

                                            <option value="Government Administration">Government Administration</option>

                                            <option value="Government Relations">Government Relations</option>

                                            <option value="Graphic Design">Graphic Design</option>

                                            <option value="Health, Wellness and Fitness">Health, Wellness and Fitness</option>

                                            <option value="Higher Education">Higher Education</option>

                                            <option value="Hospital & Health Care">Hospital & Health Care</option>

                                            <option value="Hospitality">Hospitality</option>

                                            <option value="Human Resources">Human Resources</option>

                                            <option value="Import and Export">Import and Export</option>

                                            <option value="Individual & Family Services">Individual & Family Services</option>

                                            <option value="Industrial Automation">Industrial Automation</option>

                                            <option value="Information Services">Information Services</option>

                                            <option value="Information Technology and Services">Information Technology and Services</option>

                                            <option value="Insurance">Insurance</option>

                                            <option value="International Affairs">International Affairs</option>

                                            <option value="International Trade and Development">International Trade and Development</option>

                                            <option value="Internet">Internet</option>

                                            <option value="Investment Banking">Investment Banking</option>

                                            <option value="Investment Management">Investment Management</option>

                                            <option value="Judiciary">Judiciary</option>

                                            <option value="Law Enforcement">Law Enforcement</option>

                                            <option value="Law Practice">Law Practice</option>

                                            <option value="Legal Services">Legal Services</option>

                                            <option value="Legislative Office">Legislative Office</option>

                                            <option value="Leisure, Travel & Tourism">Leisure, Travel & Tourism</option>

                                            <option value="Libraries">Libraries</option>

                                            <option value="Logistics and Supply Chain">Logistics and Supply Chain</option>

                                            <option value="Luxury Goods & Jewelry">Luxury Goods & Jewelry</option>

                                            <option value="Machinery">Machinery</option>

                                            <option value="Management Consulting">Management Consulting</option>

                                            <option value="Maritime">Maritime</option>

                                            <option value="Market Research">Market Research</option>

                                            <option value="Marketing and Advertising">Marketing and Advertising</option>

                                            <option value="Mechanical or Industrial Engineering">Mechanical or Industrial Engineering</option>

                                            <option value="Media Production">Media Production</option>

                                            <option value="Medical Devices">Medical Devices</option>

                                            <option value="Medical Practice">Medical Practice</option>

                                            <option value="Mental Health Care">Mental Health Care</option>

                                            <option value="Military">Military</option>

                                            <option value="Mining & Metals">Mining & Metals</option>

                                            <option value="Motion Pictures and Film">Motion Pictures and Film</option>

                                            <option value="Museums and Institutions">Museums and Institutions</option>

                                            <option value="Music">Music</option>

                                            <option value="Nanotechnology">Nanotechnology</option>

                                            <option value="Newspapers">Newspapers</option>

                                            <option value="Non-Profit Organization Management">Non-Profit Organization Management</option>

                                            <option value="Oil & Energy">Oil & Energy</option>

                                            <option value="Online Media">Online Media</option>

                                            <option value="Outsourcing/Offshoring">Outsourcing/Offshoring</option>

                                            <option value="Package/Freight Delivery">Package/Freight Delivery</option>

                                            <option value="Packaging and Containers">Packaging and Containers</option>

                                            <option value="Paper & Forest Products">Paper & Forest Products</option>

                                            <option value="Performing Arts">Performing Arts</option>

                                            <option value="Pharmaceuticals">Pharmaceuticals</option>

                                            <option value="Philanthropy">Philanthropy</option>

                                            <option value="Photography">Photography</option>

                                            <option value="Plastics">Plastics</option>

                                            <option value="Political Organization">Political Organization</option>

                                            <option value="Primary/Secondary Education">Primary/Secondary Education</option>

                                            <option value="Printing">Printing</option>

                                            <option value="Professional Training & Coaching">Professional Training & Coaching</option>

                                            <option value="Program Development">Program Development</option>

                                            <option value="Public Policy">Public Policy</option>

                                            <option value="Public Relations and Communications">Public Relations and Communications</option>

                                            <option value="Public Safety">Public Safety</option>

                                            <option value="Publishing">Publishing</option>

                                            <option value="Railroad Manufacture">Railroad Manufacture</option>

                                            <option value="Ranching">Ranching</option>

                                            <option value="Real Estate">Real Estate</option>

                                            <option value="Recreational Facilities and Services">Recreational Facilities and Services</option>

                                            <option value="Religious Institutions">Religious Institutions</option>

                                            <option value="Renewables & Environment">Renewables & Environment</option>

                                            <option value="Research">Research</option>

                                            <option value="Restaurants">Restaurants</option>

                                            <option value="Retail">Retail</option>

                                            <option value="Security and Investigation">Security and Investigations</option>

                                            <option value="Semiconductors">Semiconductors</option>

                                            <option value="Shipbuilding">Shipbuilding</option>

                                            <option value="Sporting Goods">Sporting Goods</option>

                                            <option value="Sports">Sports</option>

                                            <option value="Staffing and Recruiting">Staffing and Recruiting</option>

                                            <option value="Supermarkets">Supermarkets</option>

                                            <option value="Telecommunications">Telecommunications</option>

                                            <option value="Textiles">Textiles</option>

                                            <option value="Think Tanks">Think Tanks</option>

                                            <option value="Tobacco">Tobacco</option>

                                            <option value="Translation and Localization">Translation and Localization</option>

                                            <option value="Transportation/Trucking/Railroad">Transportation/Trucking/Railroad</option>

                                            <option value="Utilities">Utilities</option>

                                            <option value="Venture Capital & Private Equity">Venture Capital & Private Equity</option>

                                            <option value="Veterinary">Veterinary</option>

                                            <option value="Warehousing">Warehousing</option>

                                            <option value="Wholesale">Wholesale</option>

                                            <option value="Wine and Spirits">Wine and Spirits</option>

                                            <option value="Wireless">Wireless</option>

                                            <option value="Writing and Editing">Writing and Editing</option>


                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-lg-3 control-label">Description</label>
                                    <div class="col-lg-8">
                                        <textarea class = "form-control" style = "border:1px solid grey;" name = "description"><?php if(isset($business) and count($business) > 0): ?> <?php echo $business[0]->description; ?> <?php endif; ?></textarea>
                                    </div>
                                </div>

                                <div class = "form-group">
                                    <label class="col-lg-3 control-label">Start Year:</label>
                                    <div class = "col-lg-8">
                                        <input type = "text" required name = "start_year" class = "form-control" <?php if(isset($business) and count($business) > 0): ?> value = "<?php echo $business[0]->start_year; ?>" <?php endif; ?>>

                                    </div>
                                </div>



                                <div class="form-group">
                                    <label class="col-md-3 control-label"></label>
                                    <div class="col-md-8">
                                        <input type="submit" class="btn btn-primary" value="Save Changes">

                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<hr>
