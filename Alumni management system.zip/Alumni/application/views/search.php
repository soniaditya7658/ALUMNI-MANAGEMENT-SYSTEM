<style>
i {  vertical-align: middle; }
.table-users tbody tr:hover {
	cursor: pointer;
	background-color: #eee;
}
.nav-user-photo {
     vertical-align: middle;
}
.user_panel {
    width: 50%;
}

body{
	overflow-x:hidden;
}
</style>
<section class="row">
       

    
	<div class="panel-body">
				<div class="table-container">
                    <table class="table-users table" border="0">
                        <tbody>
                           <?php foreach ($users as $user): ?>
                            <tr>
                                <td width="10">
								<?php if($user->image != ''): ?>
                                    <img class="pull-left img-circle nav-user-photo" width="50" src="<?php echo base_url() ?>uploads/<?php echo $user->image; ?>" />  
                                <?php endif; ?>
								</td>
                                <td>
                                    <a href="<?php echo base_url() . 'index.php/Student/view/' . $user->user_id; ?>"><?php echo $user->first_name . ' ' . $user->last_name; ?>
                                </td>
                                <td>
                                   <?php echo $user->email; ?>
                                </td>
                                <td align="center">
                                    <a href="<?php echo base_url() . 'index.php/Student/view/' . $user->user_id; ?>" class="btn btn-primary"><i class="far fa-user"></i> View Profile</a>
                                </td>
                            </tr>
							 <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
			

   
	

</section>