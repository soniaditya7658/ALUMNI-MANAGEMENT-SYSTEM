<link href="<?php echo base_url(); ?>public_html/css/profile-basic.css" rel="stylesheet">
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

<div class="padding">
    <div class="full col-sm-9">
        <div class="row">
            <div class = "col-md-offset-5 col-sm-7" >
                <h3>Basic Info</h3>
                <hr>
                <div class = "col-md-12" style="text-align: center;">
					<img src="<?php echo base_url() . 'uploads/' . $basic_info->image ?>" width = "100px" height = "100px" id = "avatar" class="avatar img-circle" alt="">
                    <h5><?php echo $basic_info->first_name . ' ' . $basic_info->last_name; ?></h5>
                    <p><?php echo $basic_info->email; ?></p>
                    <p><?php echo $basic_info->course; ?></p>

                </div>

                <h3>Jobs</h3>
                <hr>
                <!-- Modal -->

                <div class = "companies">
                    <?php foreach($jobs as $job): ?>
                        <div class = "company row">
                            <div class = "col-md-2">
                                <br>
                                <i class="fa fa-building fa-4x" aria-hidden="true"></i>
                            </div>
                            <div class = "col-md-6">
                                <h5><b><?php echo $job->company_name; ?></b></h5>
                                <p><?php echo $job->position; ?></p>
                                <p><?php echo $job->start_year; ?>-<?php if($job->end_year != null): echo $job->end_year; else: echo 'Present'; endif; ?></p>
                            </div>


                        </div>


                    <?php endforeach; ?>
                </div>



                <h3>Education </h3>
                <hr>

                <div class = "companies">
                    <?php foreach ($academics as $a): ?>
                        <div class = "company row">
                            <div class = "col-md-2">
                                <br>
                                <i class="fa fa-institution fa-4x" aria-hidden="true"></i>
                            </div>
                            <div class = "col-md-6">
                                <h5><b><?php echo $a->college_name; ?></b></h5>
                                <p><?php echo $a->field_of_study; ?></p>
                                <p><?php echo $a->start_year; ?> - <?php if($a->end_year != null): echo $a->end_year; else: echo 'Present'; endif; ?></p>
                                <p><?php echo $a->degree; ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
				
				<h3>Business </h3>
                <hr>

                <div class = "companies">
                    <?php foreach ($business as $b): ?>
                        <div class = "company row">
                            <div class = "col-md-2">
                                <br>
                                <i class="fa fa-institution fa-4x" aria-hidden="true"></i>
                            </div>
                            <div class = "col-md-6">
                                <h5><b><?php echo $b->company_name; ?></b></h5>
                                <p><?php echo $b->description; ?></p>
                                <p><?php echo $b->start_year; ?> </p>
                                <p><?php echo $b->industry; ?> - <?php if($a->end_year != null): echo $a->end_year; else: echo 'Present'; endif; ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

            </div>
            <!-- main col left -->

        </div>

